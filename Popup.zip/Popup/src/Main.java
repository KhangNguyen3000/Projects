
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author CECCE
 */
public class Main {

    public static int i = 0;
    public int a = 1000000;
    public String[] args = {};
    public JFrame[] frame = new JFrame[a];
    public JPanel[] n = new JPanel[a];
    public JPanel[] m = new JPanel[a];
    public JPanel[] p = new JPanel[a];
    public JLabel[] l = new JLabel[a];
    public JButton[] b = new JButton[a];
    public JButton[] b2 = new JButton[a];

    public Main(int x) {
        frame[x] = new JFrame("Khang");
        frame[x].setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame[x].setSize(300, 150);
        frame[x].setLocation((int) (Math.random() * 1680 + 1), ((int) (Math.random() * 800 + 1)));
        m[x] = new JPanel(new BorderLayout());
        p[x] = new JPanel(new FlowLayout());
        n[x] = new JPanel(new FlowLayout());
        b[x] = new JButton("Yes");
        b2[x] = new JButton("No");
        l[x] = new JLabel("Allo");
        l[x].setFont(new Font("Serif", Font.PLAIN, 72));
        p[x].add(l[x]);
        m[x].add(p[x], BorderLayout.CENTER);
        n[x].add(b[x]);
        n[x].add(b2[x]);
        m[x].add(n[x], BorderLayout.SOUTH);
        frame[x].add(m[x]);
        frame[x].setVisible(true);

        i++;

        b[x].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
            }
        }
        );
    }

    public static void main(String args[]) {
        while (true) {
            i++;
            new Main(i);
        }
    }
}
