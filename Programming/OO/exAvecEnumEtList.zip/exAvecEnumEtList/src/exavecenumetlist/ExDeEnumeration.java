package exAvecEnumEtList;

//package exDeEnumEtList;

public class ExDeEnumeration {
     public enum MesCouleurs {rouge, vert, jaune, bleu, mauve, brun, noir, blanc, aucune}
     
     
   
}