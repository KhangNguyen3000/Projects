package exAvecEnumEtList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import exAvecEnumEtList.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ExAvecEnumEtList {

    // variables d'instance.
    private static boolean debug = true;
    private static List<InfoEx> exDeList;
    private static List<InfoEx> exP;
    public static File f = null;

    //constructeur
    public ExAvecEnumEtList() {
        System.out.println("Dans constructeur de ExAvecList");
        // réserve de la mémoire pour la liste ainsi que toute ses méthodes
        exDeList = new ArrayList();
    }

    // peite méthode privé pour faciliter de deboguing
    private static void Debug(String str) {
        if (debug) {
            System.out.println(str);
        }
    }

    /*
    * but: convertir le choix d'action de l'usager dans un numéro pour sélection
    * arguments : aucun
    * retour : une valeur numérique qui équivaut le choix
    * 0=Ajouter, 1=Rechercher, 2=Supprimer, 3=Afficher
     */
    public static int DemandePourAction() {
        // vble locales pour afficher la question et convertir le choix
        Object[] options = {"Ajouter", "Rechercher", "Supprimer", "Afficher", "Sous List"};
        int reponse = 9;

        // demande pour un choix de l'usager
        reponse = JOptionPane.showOptionDialog(null,
                "Choisi une option",
                "Les list",
                0, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        Debug("DemandePourAction - reponse=" + reponse);
        return reponse;
    }

    /*
    * but: montrer le choix de couleur et en choisi un
    * arguments : aucun
    * retour : la couleur selon le type énuméré
     */
    private static ExDeEnumeration.MesCouleurs ChoisiCouleur() {
        //vble locales pour tenir le choix
        Object[] options = new Object[9];
        Object actionChoisi = "";
        int reponse = 9;
        int i = 0;

        // boucle par toute les couleurs et place-les dans un tablo de Object
        for (ExDeEnumeration.MesCouleurs temp : ExDeEnumeration.MesCouleurs.values()) {
            options[i++] = temp;
        }

        actionChoisi = JOptionPane.showInputDialog(
                null,
                "Choisi une option",
                "Les list",
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        Debug("couleur - actionChoisi=" + actionChoisi);
        return (ExDeEnumeration.MesCouleurs) actionChoisi;
    }

    /*
    * but: ajouter un élément à la list
    * arguments : aucun, mais demande pour les 3 composantes de l'élément
    * retour : aucun, mais la liste contient un nouvel elt
     */
    public static void AjouterElt() {
        // vble locales pour représenter les vble d'instance
        String nom = "";
        ExDeEnumeration.MesCouleurs couleur = ExDeEnumeration.MesCouleurs.aucune;
        boolean aPermis = false;

        //nouvel elt de la list
        InfoEx ex = new InfoEx();
        int temp;

        // demande pour un nom
        nom = JOptionPane.showInputDialog("Donne un nom");

        // demande pour une couleur
        couleur = ChoisiCouleur();

        // demande pour un permis ou non
        temp = JOptionPane.showConfirmDialog(null, "A-t-il un permis?", "Yikes", JOptionPane.YES_NO_OPTION);
        if (temp == 0) {
            aPermis = true;
        } else {
            aPermis = false;
        }

        // rempli l'élément de la list avec les mutateurs
        ex.SetNom(nom);
        ex.SetCouleur(couleur);
        ex.SetAPermis(aPermis);

        Debug(ex.ToString());
        exDeList.add(ex);
        P();

    }

    /*
    * but: imprimer la liste
    * arguments : aucun, mais utilise la liste globale
    * retour : imprimer à écran
     */
    public static void ImprimeList() {
        Debug("num elt=" + exDeList.size());
        // passe par chaque elt et fait appel à la méthode toString.
        Debug("********************************");
        for (int i = 0; i < exDeList.size(); i++) {
            Debug(exDeList.get(i).ToString());
        }
        Debug("********************************");
    }

    public static void RechercheElt() {
        String nom;
        boolean c = false;
        nom = JOptionPane.showInputDialog(null, "C'est quoi le nom du gars que tu recherche");
        for (int i = 0; i < exDeList.size(); i++) {
            if (nom.equals(exDeList.get(i).GetNom())) {
                Debug(exDeList.get(i).ToString());
                c = true;
            }
        }
        if (c == false) {
            JOptionPane.showMessageDialog(null, "Nom non trouver");
        }
    }

    public static void SupprimeElt() {
        boolean c = false;
        String nom;
        nom = JOptionPane.showInputDialog(null, "C'est quoi le nom du gars que tu veut supprimer");
        for (int i = 0; i < exDeList.size(); i++) {
            if (nom.equals(exDeList.get(i).GetNom())) {
                Debug(exDeList.get(i).ToString() + " *******DELETED****");
                exDeList.remove(i);
                c = true;
            }
        }
        if (c == false) {
            JOptionPane.showMessageDialog(null, "Nom non trouver");
        }
        P();
        Debug("********************************");
        for (int i = 0; i < exDeList.size(); i++) {
            Debug(exDeList.get(i).ToString());
        }
        Debug("********************************");
    }

    public static File FileChoose() {
        boolean continu = true;
        do {
            File fichier = null;
            JFileChooser fileChooser
                    = new JFileChooser(System.getProperty("user.dir"));
            int valRetour = fileChooser.showOpenDialog(null);
            if (valRetour == 0) {
                fichier = fileChooser.getSelectedFile();
                continu = false;
                if (!fichier.isFile()) {
                    continu = true;
                }

            } else {
                System.exit(0);
            }
            return fichier;
        } while (continu == true);
    }

    public static void P() {
        PrintWriter p = null;
        try {
            p = new PrintWriter(new BufferedWriter(new FileWriter(f, false)));
        } catch (IOException ex) {
        }
        for (int i = 0; i < exDeList.size(); i++) {
            p.println(exDeList.get(i).GetNom() + " " + exDeList.get(i).GetCouleur() + " " + exDeList.get(i).GetAPermis());
        }
        p.close();
    }

    static void Start() {
        int x = 0;
        boolean c = true;
        Scanner p = null;
        try {
            p = new Scanner(f);
        } catch (IOException ex) {
            c = false;
        }
        if (c == true) {
            while (p.hasNext()) {
                InfoEx ex = new InfoEx();
                String nom = p.next();
                String couleur = p.next();
                boolean permi = p.nextBoolean();
                ex.SetNom(nom);
                ex.SetCouleurA(couleur);
                ex.SetAPermis(permi);
                exDeList.add(ex);
            }
        }
    }

    public static void SousList() {
        Debug("********************************");
        for (int i = 0; i < exDeList.size(); i++) {
            if (exDeList.get(i).GetAPermis() == true) {
                Debug(exDeList.get(i).ToString());
            }
        }
        Debug("********************************");
    }

    public static void main(String[] args) {
        f = FileChoose();
        int choix = 9;
        ExAvecEnumEtList ex1 = new ExAvecEnumEtList();
        Start();
        do {
            switch (DemandePourAction()) {
                case 0:
                    AjouterElt();
                    break;
                case 1:
                    RechercheElt();
                    break;
                case 2:
                    SupprimeElt();
                    break;
                case 3:
                    ImprimeList();
                    break;
                case 4:
                    SousList();
                    break;
            }

            choix = JOptionPane.showConfirmDialog(null, "Continue?");
        } while (choix == 0);
    }
}
