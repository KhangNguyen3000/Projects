package exAvecEnumEtList;

import exAvecEnumEtList.ExDeEnumeration;
/*
 * Utilise ceci pour exemple de OO et de list en classe
 */
public class InfoEx {
   // explique le concept des enumerations
   // variables d'instance
   private String nom;
   private ExDeEnumeration.MesCouleurs couleur;
   private boolean aPermis;

   // le constructeur
   public InfoEx () {
      nom="PasDeNom";
      couleur = ExDeEnumeration.MesCouleurs.aucune;
      aPermis=false;
   }

   // Les mutateurs
   public void SetNom(String nm) {
      this.nom = nm;
   }

   public void SetCouleur(ExDeEnumeration.MesCouleurs maPreference) {
      this.couleur = maPreference;
   }
   
   public void SetCouleurA (String a){
   this.couleur = ExDeEnumeration.MesCouleurs.valueOf(a);
   }

   public void SetAPermis(boolean rep) {
      this.aPermis = rep;
   }

   // les accesseurs
   public InfoEx GetInfo () {
      return this;
   }

   public String GetNom() {
      return this.nom;
   }

   public ExDeEnumeration.MesCouleurs GetCouleur() {
      return this.couleur;
   }

   public boolean GetAPermis() {
      return this.aPermis;
   }

   // pour affichage
   public String ToString(){
      return "nom="+this.nom+"  couleur="+this.couleur+"  aPermis="+this.aPermis;
   }

}