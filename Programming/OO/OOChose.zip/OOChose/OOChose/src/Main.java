
import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.GridLayout;
import java.awt.FlowLayout;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author CECCE
 */
public class Main {

    List<Object> l = new ArrayList<>();

    public Main() {
        JFrame f = new JFrame("allo");
        f.setSize(600, 400);
        
        JPanel p = new JPanel(new FlowLayout());

        f.setVisible(true);

    }

    public File FileChoose() {
        boolean continu = true;
        do {
            File fichier = null;
            JFileChooser fileChooser
                    = new JFileChooser(System.getProperty("user.dir"));
            int valRetour = fileChooser.showOpenDialog(null);
            if (valRetour == 0) {
                fichier = fileChooser.getSelectedFile();
                continu = false;
                if (!fichier.isFile()) {
                    continu = true;
                }

            } else {
                System.exit(0);
            }
            return fichier;
        } while (continu == true);
    }

    public void Auto() {
        int x = 0;
        File f = FileChoose();
        Scanner p = null;
        try {
            p = new Scanner(f);
        } catch (IOException ex) {
        }
        while (p.hasNextLine()) {
            AvionDeTerre a = Demande(x, p);
            System.out.println(a.Nom() + " de couleur: " + a.Couleur() + " utilise :" + a.Consome() + " MPG  |  et :" + a.Consome2() + "L/100KM");
            l.add(a);
        }
    }

    public AvionDeTerre Demande(int x, Scanner p) {
        AvionDeTerre a = new AvionDeTerre(p);
        a.SetNom();
        a.SetCoule();
        a.SetStart();
        a.SetEnd();
        a.SetLitre();
        return a;
    }

    public static void main(String args[]) {
        Main m = new Main();
    }
}
