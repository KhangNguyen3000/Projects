
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author CECCE
 */
public class AvionDeTerre {

    private double start;
    private double fini;
    private double gallon;
    private String nom;
    private String coule;
    Scanner q = null;

    public AvionDeTerre(Scanner s) {
        q = s;
    }

    void SetStart() {
        start = Double.parseDouble(q.next());
    }

    void SetEnd() {
        fini = Double.parseDouble(q.next());
    }

    void SetLitre() {
        gallon = Double.parseDouble(q.next());
    }

    void SetCoule() {
        coule = q.next();
    }

    void SetNom() {
        nom = q.next();
    }

    String Nom() {
        return nom;
    }
    
    String Couleur() {
        return coule;
    }

    double Consome() {
        double finale = ((fini - start) * 0.62) / (gallon * 0.26);
        return finale;
    }

    double Consome2() {
        double finale = ((gallon) / ((fini - start))) * 100;
        return finale;
    }
}
