
import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author CECCE
 */
public class Main {

    File f = null;
    List<Object> o = new ArrayList<>();
    JFrame frame = new JFrame();
    JPanel[] p = new JPanel[6];
    JButton b = new JButton();
    int tV = 5;
    JTextField[] t = new JTextField[tV];
    JLabel[] l = new JLabel[6];

    public Main() {
        f = FileChoose();
        GUI();

    }

    public void GUI() {
        frame = new JFrame("Ajoute Auto");
        frame.setSize(600, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        p[1] = new JPanel(new FlowLayout());
        b = new JButton("Ajoute");
        p[1].add(b);

        p[2] = new JPanel(new GridLayout(5, 1));
        for (int x = 0; x < tV; x++) {
            t[x] = new JTextField();
            p[2].add(t[x]);
        }
        p[3] = new JPanel(new GridLayout(5, 1));
        l[0] = new JLabel("Nom");
        p[3].add(l[0]);
        l[1] = new JLabel("Couleur");
        p[3].add(l[1]);
        l[2] = new JLabel("KM Debut");
        p[3].add(l[2]);
        l[3] = new JLabel("KM Fin");
        p[3].add(l[3]);
        l[4] = new JLabel("Litres Utiliser");
        p[3].add(l[4]);

        p[4] = new JPanel(new FlowLayout());
        l[5] = new JLabel("Ajoute Auto");
        l[5].setFont(new Font("Arial", Font.BOLD, 28));
        p[4].add(l[5]);

        p[0] = new JPanel(new BorderLayout());
        p[0].add(p[1], BorderLayout.SOUTH);
        p[0].add(p[2], BorderLayout.CENTER);
        p[0].add(p[3], BorderLayout.WEST);
        p[0].add(p[4], BorderLayout.NORTH);
        frame.add(p[0]);
        frame.setVisible(true);

        b.addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                BPeser();
            }
        }
        );
    }

    public File FileChoose() {
        boolean continu = true;
        do {
            File fichier = null;
            JFileChooser fileChooser
                    = new JFileChooser(System.getProperty("user.dir"));
            int valRetour = fileChooser.showOpenDialog(null);
            if (valRetour == 0) {
                fichier = fileChooser.getSelectedFile();
                continu = false;
                if (!fichier.isFile()) {
                    continu = true;
                }

            } else {
                System.exit(0);
            }
            return fichier;
        } while (continu == true);
    }

    public void BPeser() {
        PrintWriter p = null;
        String[] s = new String[tV];
        try {
            p = new PrintWriter(new BufferedWriter(new FileWriter(f, true)));
        } catch (IOException ex) {
        }
        p.println();
        for (int x = 0; x < tV; x++) {
            s[x] = t[x].getText();
            p.print(s[x] + " ");
        }
        p.close();
        Auto();
    }

    public void Auto() {
        int x = 0;
        Scanner p = null;
        try {
            p = new Scanner(f);
        } catch (IOException ex) {
        }
        while (p.hasNextLine()) {
            AvionDeTerre a = Demande(x, p);
            System.out.println(a.Nom() + " de couleur: " + a.Couleur() + " utilise :" + a.Consome() + " MPG  |  et :" + a.Consome2() + "L/100KM");
            o.add(a);
            p.nextLine();
        }
    }

    public AvionDeTerre Demande(int x, Scanner p) {
        AvionDeTerre a = new AvionDeTerre(p);
        a.SetNom();
        a.SetCoule();
        a.SetStart();
        a.SetEnd();
        a.SetLitre();
        return a;
    }

    public static void main(String args[]) {
        Main m = new Main();
    }
}
