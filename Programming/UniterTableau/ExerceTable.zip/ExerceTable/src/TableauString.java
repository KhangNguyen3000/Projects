
import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author CECCE
 */
public class TableauString {

    public static void main(String args[]) {
        int x = 5;
        String[] t = new String[x];

        for (int i = 0; i < x; i++) {
            String k = JOptionPane.showInputDialog("Nom");
            t[i] = k;
        }

        for (int i = 0; i < x; i++) {
            System.out.println("Indice: " + i + " Valeur pour T1: " + t[i]);
        }

    }
}
