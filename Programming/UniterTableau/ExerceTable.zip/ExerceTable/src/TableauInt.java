/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;

/**
 *
 * @author CECCE
 */
public class TableauInt {

    public static void main(String args[]) {
        int x = 5;
        int[] t = new int[x];
        int[] t2 = new int[x];

        for (int i = 0; i < x; i++) {
            int k = Integer.parseInt(JOptionPane.showInputDialog("numéro"));
            t[i] = k;
            t2[i] = t[i] * 2;
        }

        for (int i = 0; i < x; i++) {
            System.out.println("Indice: " + i + " Valeur pour T1: " + t[i] + " Valeur pour T2: " + t2[i]);
        }

    }
}
