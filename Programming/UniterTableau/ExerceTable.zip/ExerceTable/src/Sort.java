import javax.swing.*;

public class Sort {

    public Sort(int x) {
        int[] t = new int[x];
        int k = Echelle(x);

        t = UniAle(t, k);
        TAff1(t);
        t = Sorter(t);
        TAff2(t);
    }

    public int Echelle(int x) {
        int k = 0;
        do {
            k = Integer.parseInt(JOptionPane.showInputDialog("0 à quel nombre"));
        } while (k < x);
        return k;
    }

    public int[] UniAle(int[] t, int k) {
        for (int i = 0; i < t.length; i++) {
            boolean f = true;
            do {
                t[i] = (int) (Math.random() * (k + 1));
                f = true;
                for (int r = 0; r < i; r++) {
                    System.out.println(t[r] + " et " + t[i]);
                    if (t[r] == t[i]) {
                        f = false;
                        break;
                    }
                }
            } while (f == false);
        }
        return t;
    }

    public void TAff1(int[] t) {
        for (int i = 0; i < t.length; i++) {
            System.out.println("Indice: " + i + " Valeur pour T1: " + t[i]);
        }
        System.out.println("-------------------------------------------------------");
    }

    public int[] Sorter(int[] t) {
        for (int i = (t.length - 1); i >= 0; i--) {
            for (int r = 0; r < i; r++) {
                if (t[r] > t[i]) {
                    int a = t[i];
                    t[i] = t[r];
                    t[r] = a;
                }
            }
        }
        return t;
    }

    public void TAff2(int[] t) {
        for (int i = 0; i < t.length; i++) {
            System.out.println("Indice: " + i + " Valeur pour T2: " + t[i]);
        }
    }

    public static void main(String args[]) {
        int k = Integer.parseInt(JOptionPane.showInputDialog("Insère le nombre d'élément"));
        new Sort(k);
    }
}