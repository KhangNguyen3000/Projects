
import java.util.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class Main {

    public static boolean prime = false;

    public static void main(String args[]) {
        int a = -1;
        String b;
        Scanner sc = new Scanner(System.in);
        b = sc.nextLine();
        if (b.equals("")) {}else{
        a = Integer.parseInt(b);
        }
            for (int i = 2; i != a; i++) {
                prime = true;
                for (int x = 2; x < i; x++) {
                    if (i % x == 0) {
                        prime = false;
                        break;
                    }
                }
                if (prime == true) {
                    System.out.println(i);
                }
            }
        }
    }

