
import java.util.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class Main {

    public static void main(String args[]) {
        String str = "";
        boolean done = false;
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();

        do {
            for (int x = 2; x <= a;) {
                if (a % x == 0) {
                    str = str+x+" ";
                    a = a / x;
                }else{
                x++;
                }
            }
            done = true;
            System.out.println(str);
        }while (done == false);
    
    }
}
