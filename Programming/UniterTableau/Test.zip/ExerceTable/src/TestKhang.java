
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author CECCE
 */
public class TestKhang {

    public JFrame frame = new JFrame();
    public JPanel n = new JPanel();
    public JPanel m = new JPanel();
    public JPanel p = new JPanel();
    public JLabel l = new JLabel();
    public JButton b[] = new JButton[5];

    public TestKhang() {
        frame = new JFrame("Khang");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(720, 240);
        frame.setLocationRelativeTo(null);
        m = new JPanel(new BorderLayout());
        p = new JPanel(new FlowLayout());
        n = new JPanel(new FlowLayout());
        b[0] = new JButton("Question 1");
        b[1] = new JButton("Question 2");
        b[2] = new JButton("Question 3");
        b[3] = new JButton("Question 4");
        l = new JLabel("Choisi une question");
        l.setFont(new Font("Serif", Font.PLAIN, 72));
        p.add(l);
        m.add(p, BorderLayout.CENTER);
        n.add(b[0]);
        n.add(b[1]);
        n.add(b[2]);
        n.add(b[3]);
        m.add(n, BorderLayout.SOUTH);
        frame.add(m);
        frame.setVisible(true);
        for (int x = 0; x < 4; x++) {
            final int k = x;
            b[x].addActionListener(
                    new ActionListener() {
                public void actionPerformed(ActionEvent u) {
                    QuelleQuestion(k);
                }
            }
            );
        }
    }

    public void QuelleQuestion(int x) {
        switch (x) {
            case 0:
                Question1();
                break;
            case 1:
                Question2();
                break;
            case 2:
                Question3();
                break;
            case 3:
                Question4();
                break;
            default:
                System.out.println("Choisi un question");
                break;
        }
    }

    public void Question1() {
        int x = NombredIndice();
        int k = Echelle(x);
        int[] t = new int[x];
        t = UniAle(x, k);
        TAff1(t);
    }

    public void Question2() {
        int x = NombredIndice();
        int k = Echelle(x);
        int[] t = new int[x];
        t = UniAle(x, k);
        TAff1(t);
    }

    public void Question3() {
        int x = NombredIndice();
        int k = Echelle(x);
        int[] t = new int[x];
        t = UniAle(x, k);
        TAff1(t);
    }

    public void Question4() {
        int x = NombredIndice();
        int k = Echelle(x);
        int[] t = new int[x];
        t = UniAle(x, k);
        TAff1(t);
    }

    public int NombredIndice() {
        int k = Integer.parseInt(JOptionPane.showInputDialog("Insère le nombre d'élément"));
        return k;
    }

    public int Echelle(int x) {
        int k = 0;
        do {
            k = Integer.parseInt(JOptionPane.showInputDialog("0 à quel nombre"));
        } while (k < x);
        return k;
    }

    public int[] UniAle(int x, int k) {
        int[] t = new int[x];
        for (int i = 0; i < t.length; i++) {
            boolean f = true;
            do {
                t[i] = (int) (Math.random() * (k + 1));
                f = true;
                for (int r = 0; r < i; r++) {
                    System.out.println(t[r] + " et " + t[i]);
                    if (t[r] == t[i]) {
                        f = false;
                        break;
                    }
                }
            } while (f == false);
        }
        return t;
    }

    public void TAff1(int[] t) {
        for (int i = 0; i < t.length; i++) {
            System.out.println("Indice: " + i + " Valeur pour T1: " + t[i]);
        }
        System.out.println("-------------------------------------------------------");
    }

    public static void main(String args[]) {
        new TestKhang();
    }
}
