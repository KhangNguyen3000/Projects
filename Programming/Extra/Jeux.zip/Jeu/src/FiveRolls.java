
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author KhangNguyen
 */
public class FiveRolls {

    private JFrame frame;
    private JPanel panel;
    private JLabel l1, s1;
    private JButton b1;
    private int numD = 0, monD = 0, rouleV;
    public static String nom;

    public FiveRolls() {
        nom = JOptionPane.showInputDialog(null, "Nom du Joueur");
        gui();
    }

    public class RouleB implements ActionListener {

        public void actionPerformed(ActionEvent v) {
            rouleV = (Roule());
            GuiUp();
            frame.dispose();
            gui();
        }

    }

    public int Roule() {
        return ((int) (Math.random() * 6 + 1));
    }

    public void GuiUp() {
        monD++;
        if (monD == 5) {
            Fini();
        } else if (rouleV == 2 || rouleV == 4 || rouleV == 6) {
            numD++;
            System.out.println("valeur nouveau:" + numD);
        } else {
            System.out.println("montant nouveau:" + monD);
        }
    }

    public void gui() {
        frame = new JFrame("Five Rolls");
        frame.setSize(450, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        panel = new JPanel(new GridLayout(3, 1));

        b1 = new JButton("Roule");
        panel.add(b1);
        s1 = new JLabel("Score " + nom + " | Nombre de dés paires:" + numD + "/3 | Nombre de dé rouler:" + monD + "/5");
        panel.add(s1);
        l1 = new JLabel("Tu as rouler un: " + rouleV);
        panel.add(l1);

        frame.add(panel);

        RouleB v = new RouleB();
        b1.addActionListener(v);
    }

    public void Fini() {
        int i;
        if (numD >= 3) {
            i = JOptionPane.showConfirmDialog(null, "FELICITATION " + nom + "! TU AS GAGNER! Veut tu jouer encore?");
        } else {
            i = JOptionPane.showConfirmDialog(null, "FELICITATION " + nom + "! TU AS PERDUE! Veut tu jouer encore?");
        }
        if (i == 0) {
            frame.dispose();
            numD = 1;
            monD = 0;
            rouleV = 0;
            nom = JOptionPane.showInputDialog(null, "Nom du Joueur");
            gui();
        } else {
            frame.dispose();
        }
    }

    public static void main(String args[]) {
        new FiveRolls();
    }
}
