
import java.util.Scanner;

/**
 *
 * @author KhangNguyen
 */
public class TSelection {

    public static void main(String args[]) {
        String wl;
        int win = 0;
        for (int i = 1; i <= 6; i++) {
            Scanner en = new Scanner(System.in);
            wl = en.nextLine();
            if ("W".equals(wl)) {
                win++;
            }

        }
        switch (win) {
            case 1:
            case 2:
                System.out.println("3");
                break;
            case 3:
            case 4:
                System.out.println("2");
                break;
            case 5:
            case 6:
                System.out.println("1");
                break;
            default:
                System.out.println("-1");
                break;
        }
    }
}
