
import java.util.Scanner;

/**
 *
 * @author KhangNguyen
 */
public class hPalin {

    public static void main(String args[]) {
        String line;
        int length, z = 0, out, out2 = 0;
        Scanner en = new Scanner(System.in);
        line = en.nextLine();
        length = line.length();
        if (length == 1) {
            System.out.println("1");
            System.exit(0);
        }
        for (int x = 0; x < length; x++) {
            System.out.println("x" + x);
            z = 0;
           for (x - z >= 0) {
                while (line.charAt(x - z) == line.charAt(x + z)) {
                    z++;
                    System.out.println(2 * z);
                }
            }

        }
    }
}
