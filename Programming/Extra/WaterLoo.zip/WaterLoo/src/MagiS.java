
import java.util.Scanner;

/**
 *
 * @author KhangNguyen
 */
public class MagiS {

    public static void main(String args[]) {
        int check = 0, y = 0;
        String line, sint = "";
        int total[] = new int[8];
        int pos[][] = new int[4][4];
        for (int f = 0; f < 4; f++) {
            Scanner en = new Scanner(System.in);
            line = en.nextLine();
            for (int x = 0; x <= line.length(); x++) {
                if (x == line.length()) {
                    pos[f][y] = Integer.parseInt(sint);
                    sint = "";
                    y++;
                } else if (line.charAt(x) == ' ') {
                    pos[f][y] = Integer.parseInt(sint);
                    sint = "";
                    y++;
                } else {
                    sint = sint + line.charAt(x);
                }
            }
            y = 0;
        }
        for (int f = 0; f < 4; f++) {
            for (int i = 0; i < 4; i++) {
                total[f] = pos[f][i] + total[f];
            }
        }
        for (int f = 0; f < 4; f++) {
            for (int i = 0; i < 4; i++) {
                total[f + 4] = pos[i][f] + total[f + 4];
            }
        }
        do {
            if (check == 7) {
                System.out.println("magic");
                System.exit(0);
            }
            check++;
        }while (total[check] == total[check - 1]);
        System.out.println("not magic");
    }
}
