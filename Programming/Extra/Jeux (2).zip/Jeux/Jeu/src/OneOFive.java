
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author KhangNguyen
 */
public class OneOFive {

    private JFrame frame;
    private JPanel panel, panel2;
    private JLabel l1, l2, s1, s2;
    private JButton b1;
    private int tour = 1, numD1 = 1, numD2 = 1, monD1 = 0, monD2 = 0, rouleV;
    public static String nom1, nom2;

    public OneOFive() {
        nom1 = JOptionPane.showInputDialog(null, "Nom du Joueur 1");
        nom2 = JOptionPane.showInputDialog(null, "Nom du Joueur 2");
        gui();
    }

    public class RouleB implements ActionListener {

        public void actionPerformed(ActionEvent v) {
            rouleV = (Roule());

            if (tour == 1) {
                if (rouleV == numD1) {
                    GuiUp(tour);
                    tour = 2;
                } else {
                    System.out.println("Pas le bon valeur1");
                    tour = 2;
                }
            } else if (tour == 2) {
                if (rouleV == numD1) {
                    GuiUp(tour);
                    tour = 1;
                } else {
                    System.out.println("Pas le bon valeur2");
                    tour = 1;
                }
            } else {
                System.out.println("erreur de logic");
            }
            System.out.println("Tour du joueur" + tour);
            // frame.dispose();
            // gui();
            UpGUI();
        }

    }

    public int Roule() {
        return ((int) (Math.random() * 6 + 1));
    }

    public void GuiUp(int tour) {
        if (tour == 1) {
            monD1++;
            if (monD1 == 5) {
                if (numD1 == 6) {
                    Fini(nom1);
                } else {
                    monD1 = 0;
                    numD1++;
                }
                System.out.println("valeur nouveau:" + numD1);
            } else {
                System.out.println("montant nouveau:" + monD1);
            }
        } else {
            monD2++;
            if (monD2 == 5) {
                if (numD2 == 6) {
                    Fini(nom2);
                } else {
                    monD2 = 0;
                    numD2++;
                }
                System.out.println("valeur nouveau:" + numD2);
            } else {
                System.out.println("montant nouveau:" + monD2);
            }
        }
    }
public void UpGUI(){
            s1.setText("Score " + nom1 + " | Valeur du dé:" + numD1 + "/6 | Montant de dé:" + monD1 + "/5");
            s2.setText("Score " + nom2 + " | Valeur du dé:" + numD2 + "/6 | Montant de dé:" + monD2 + "/5");
            if (tour != 1) {
                l1.setText("Tu as rouler un: " + rouleV);
                l2.setText("Tu as rouler un: ");
            } else if (tour != 2) {
                l2.setText("Tu as rouler un: " + rouleV);
                l1.setText("Tu as rouler un: ");
            } else {
                System.out.println("erreur");
            }
}
    public void gui() {
        frame = new JFrame("One-O-Five");
        frame.setSize(500, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        panel = new JPanel(new GridLayout(2, 1));
        panel2 = new JPanel (new BorderLayout());

        b1 = new JButton("Roule");
        panel2.add(b1, BorderLayout.NORTH);
        s1 = new JLabel("Score " + nom1 + " | Valeur du dé:" + numD1 + "/6 | Montant de dé:" + monD1 + "/5");
        panel.add(s1);
        l1 = new JLabel("Tu as rouler un: ");
        panel2.add(l1,BorderLayout.WEST);
        s2 = new JLabel("Score " + nom2 + " | Valeur du dé:" + numD2 + "/6 | Montant de dé:" + monD2 + "/5");
        panel.add(s2);
        l2 = new JLabel("Tu as rouler un: ");
        panel2.add(l2,BorderLayout.EAST);
frame.add(panel2);
        panel2.add(panel, BorderLayout.CENTER);
        frame.add(panel2);

        RouleB v = new RouleB();
        b1.addActionListener(v);
    }

    public void Fini(String nom) {
        int i = JOptionPane.showConfirmDialog(null, "FELICITATION " + nom + "! TU AS GAGNER! Voulez vous jouer encore?");

        if (i == 0) {
            frame.dispose();
            tour = 1;
            numD1 = 1;
            numD2 = 1;
            monD1 = 0;
            monD2 = 0;
            rouleV = 0;
            nom1 = JOptionPane.showInputDialog(null, "Nom du Joueur 1");
            nom2 = JOptionPane.showInputDialog(null, "Nom du Joueur 2");
            gui();
        } else {
            frame.dispose();
        }
    }

    public static void main(String args[]) {
        new OneOFive();
    }
}
