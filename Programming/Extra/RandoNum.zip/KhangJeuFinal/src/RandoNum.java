/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author KhangNguyen
 */
public class RandoNum {

    public boolean debogue = true;
    public boolean t = false;

    public String nom = Main.nom;
    public int[] i = Main.i;
    public int n = 0, ms = 0, s = 0;
    public ArrayList x = new ArrayList();
    private Timer timer = null;
    public JFrame frame;
    public JPanel[] m = new JPanel[3];
    public JButton[] b = new JButton[(i[0] * i[1])];
    public JPanel[] p = new JPanel[2];
    public JLabel[] l = new JLabel[2];

    public void D(String e) {//debug
        if (debogue == true) {
            System.out.println(e);
        }
    }

    public RandoNum() {
        Start();
    }

    public void Start() {
        ValDBoutons();
        gui();
    }

    public void ValDBoutons() {
        for (int z = 1; z <= (i[0] * i[1]); z++) {
            x.add(z);
        }
        Collections.shuffle(x);
        D("" + (i[0] * i[1]));
    }

    public void gui() {
        frame = new JFrame("RandoNum");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        if (i[0] < 8) {
            frame.setSize(200 + ((i[0] * 55)), (70 + (i[1]) * 55));
        } else {
            frame.setSize(20 + ((i[0] * 55)), (70 + (i[1]) * 55));
        }
        frame.setLocationRelativeTo(null);

        //NORTH
        m[1] = new JPanel(new GridLayout(1, 2));
        p[0] = new JPanel(new FlowLayout());
        l[0] = new JLabel("Nom: " + nom);
        p[0].add(l[0]);
        m[1].add(p[0]);
        p[1] = new JPanel(new FlowLayout(FlowLayout.LEFT));
        l[1] = new JLabel("Temps: ");
        p[1].add(l[1]);
        m[1].add(p[1]);

        //CENTER
        m[2] = new JPanel(new GridLayout(i[1], i[0]));
        for (int z = 0; z < (i[0] * i[1]); z++) {
            b[z] = new JButton("" + (x.get(z)));
            // p[z] = new JPanel(new FlowLayout());

            // p[z].add(b[z]);
            m[2].add(b[z]);
            D("" + z + " valeur " + (x.get(z)));
        }

        m[0] = new JPanel(new BorderLayout());
        m[0].add(m[1], BorderLayout.NORTH);
        m[0].add(m[2], BorderLayout.CENTER);
        frame.add(m[0]);
        frame.setVisible(true);

        for (int x = 0; x < (i[0] * i[1]); x++) {
            int k = x;
            b[x].addActionListener(
                    new ActionListener() {
                public void actionPerformed(ActionEvent u) {
                    D("Location du bouton = " + k);
                    BPeser(k);
                }
            }
            );
        }
    }

    public void BPeser(int k) {
        D("Valeur voulu = " + (n + 1));
        int v = (Integer.parseInt(b[k].getText()));
        D("Valeur du Bouton = " + v);
        if (v == (n + 1)) {
            n = n + 1;
            b[k].setEnabled(false);
        } else {

        }

        if (n == ((i[0] * i[1]))) {
            Fini();
        }

        D("Nouvelle valeur = " + n);
        if (t == false) {
            timer = new Timer(20, new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    ms++;
                    if (ms >= 48) {//il y a un decalage a 50
                        ms = 0;
                        s++;
                    }
                        l[1].setText("Temps: " + s + "." + String.format("%02d", ms));

                }
            });
            timer.start();
            t = true;
        }
    }

    public void Fini() {
        int i = JOptionPane.showConfirmDialog(null, "FELICITATION " + nom + "! TU AS GAGNER AVEC UN TEMPS DE " + s + "." + String.format("%02d", ms) + " SECONDES! \nVoulez vous assaier encore?");
        if (i == 0) {
            D("Recommence le Jeu");
            frame.dispose();
            new RandoNum();//le gui refait tous les valeurs deja donc execute gui
        } else {
            D("Ferme le JFrame");
            System.exit(0);
        }
    }

    public static void main(String args[]) {
        new RandoNum();
    }
}
