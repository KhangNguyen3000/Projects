
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class Main {

    public static int[] i = new int[2];
    public static String nom;
    public static String[] args = {};

    public static void CheckEntre(String str, int x) {
        if (str == null) {
            System.exit(0);
        }
        try {
            i[x] = Integer.parseInt(str);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, str + " n'est pas un nombre.");
        }
    }

    public static void main(String args[]) {
        nom = JOptionPane.showInputDialog(null, "C'est quoi ton nom?");
        if (nom == null) {
            System.exit(0);
        }

        String strI;
        for (int x = 0; x < 2; x++) {
            if (x == 0) {
                do {
                    strI = JOptionPane.showInputDialog(null, "Combien de colonnes?(minimum 2)");
                    CheckEntre(strI, x);
                } while (i[x] < 2);
            } else {
                do {
                    strI = JOptionPane.showInputDialog(null, "Combien de rangé?(minimum 2)");
                    CheckEntre(strI, x);
                } while (i[x] < 2);
            }
        }
        RandoNum.main(args);
    }
}
