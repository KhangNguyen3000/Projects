import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author CECCE
 */
public class Main4 {

    public static int loc[] = new int[5];
    public static String line, sint = "";
    public static void main(String args[]) {
                        int z =0;
        for (int f = 0; f < 3; f++) {
            Scanner en = new Scanner(System.in);
            line = en.nextLine();
            for (int x = 0; x < line.length(); x++) {
                if (x == (line.length()-1)) {
                    sint = sint + line.charAt(x);
                    loc[z] = Integer.parseInt(sint);
                    sint = "";
                    z++;
                } else if (line.charAt(x) == ' ') {
                    loc[z] = Integer.parseInt(sint);
                    sint = "";
                    z++;
                } else {
                    sint = sint + line.charAt(x);
                }
            }
        }
        for (int i = 0; i < loc[4]; i++) {
            if (loc[0] < loc[2]) {
                loc[0]++;
            } else if (loc[0] > loc[2]) {
                loc[0]--;
            } else if (loc[1] < loc[3]) {
                loc[1]++;
            } else if (loc[1] > loc[3]) {
                loc[1]--;
            } else if (loc[0] == loc[2]) {
                    loc[0]--;
            } else if (loc[1] == loc[3]) {
                    loc[1]--;
            }
        }
        if (loc[0] == loc[2] && loc[1] == loc[3]) {
            System.out.println("Y");
        } else {
            System.out.println("N");
        }

    }
}
