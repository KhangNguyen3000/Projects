
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CECCE
 */
public class Main3 {
    
    public static int a[] = new int[2];
    public static String line;
    public static int total = 0, b;

    public static void main(String args[]) {
        Scanner en = new Scanner(System.in);
        for (int i = 0; i <= 1; i++) {
            line = en.nextLine();
            a[i] = Integer.parseInt(line);
        }
        b = a[0];
        for (int i = 0; i <= a[1]; i++){
        total = total + b;
        b = b*10;
        }
        System.out.println(total);
    }
}
