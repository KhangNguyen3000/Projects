
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author CECCE
 */
public class Main {

    public static String line, temp;
    public static int t[] = new int[5];
    public static int d, y = 0;

    public static void main(String args[]) {
        line = "12:00";
        Scanner en = new Scanner(System.in);
        d = en.nextInt();
        if (line.length() == 4) {
            temp = "" + line.charAt(0);
            t[1] = Integer.parseInt(temp);
            temp = "" + line.charAt(2);
            t[2] = Integer.parseInt(temp);
            temp = "" + line.charAt(3);
            t[3] = Integer.parseInt(temp);

        } else {
            temp = "" + line.charAt(0) + line.charAt(1);
            t[1] = Integer.parseInt(temp);
            temp = "" + line.charAt(3);
            t[2] = Integer.parseInt(temp);
            temp = "" + line.charAt(4);
            t[3] = Integer.parseInt(temp);
            temp = "" + line.charAt(0);
            t[0] = Integer.parseInt(temp);
            temp = "" + line.charAt(1);
            t[4] = Integer.parseInt(temp);
        }
        for (int i = 1; i <= d; i++) {
            t[3]++;
            if (t[3] == 10) {
                t[3] = 0;
                t[2]++;
            }
            if (t[2] == 6) {
                t[2] = 0;
                t[1]++;
            }
            if (t[1] == 13) {
                t[1] = 1;
            }
            line = t[1]+":"+t[2]+t[3];
            if (line.length() == 4) {
                for (int z = 0; z <= 5; z++) {
                    if (t[1] + z == t[2] && t[2] + z == t[3]) {
                        y++;
                        System.out.println(line);
                    } else if (t[1] - z == t[2] && t[2] - z == t[3]) {
                        y++;
                        System.out.println(line);
                    }
                }
            } else {
                for (int z = 0; z <= 3; z++) {
                    if (t[0] + z == t[4] && t[4] + z == t[2] && t[2] + z == t[3]) {
                        y++;
                        System.out.println(line);
                    } else if (t[0] - z == t[4] && t[4] - z == t[2] && t[2] - z == t[3]) {
                        y++;
                        System.out.println(line);
                    }
                }
            }
        }
        System.out.println(y);
    }
}
