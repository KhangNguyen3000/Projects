
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author KhangNguyen
 */
public class OneOFive {

    private JFrame frame;
    private JPanel panel, panel2;
    private JLabel l1, l2, s1, s2;
    private JButton b1, b2;
    private int tour = 1, numD1 = 1, numD2 = 1, monD1 = 0, monD2 = 0, rouleV;
    public static String nom1, nom2;

    public class Roule1 implements ActionListener {

        public void actionPerformed(ActionEvent u) {
            rouleV = (Roule());

            switch (tour) {
                case 1:
                    if (rouleV == numD1) {
                        monD1++;
                        numD1 = NumUp(monD1, numD1, nom1);
                        monD1 = NewMon(monD1);
                    } else {
                        System.out.println("Pas le bon valeur1");
                    }
                    tour = 2;
                    PariNon(numD2);
                    break;
                case 2:
                    if (rouleV == numD2) {
                        monD2++;
                        numD2 = NumUp(monD2, numD2, nom2);
                        monD2 = NewMon(monD2);
                    } else {
                        System.out.println("Pas le bon valeur2");
                    }
                    tour = 1;
                    PariNon(numD1);
                    break;
                default:
                    System.out.println("erreur de logic");
                    break;
            }
            System.out.println("Tour du joueur" + tour);
            UpGUI();
        }

    }

    public class Pari implements ActionListener {

        public void actionPerformed(ActionEvent d) {
            rouleV = (Roule());

            switch (tour) {
                case 1:
                    if (rouleV == numD1) {
                        monD1 = 0;
                        numD1++;
                    } else {
                        monD1 = 0;
                        numD1--;
                        System.out.println("Pas le bon valeur1");
                    }
                    tour = 2;
                    PariNon(numD2);
                    break;
                case 2:
                    if (rouleV == numD2) {
                        monD2++;
                        numD2++;
                    } else {
                        monD2 = 0;
                        numD2--;
                        System.out.println("Pas le bon valeur2");
                    }
                    tour = 1;
                    PariNon(numD1);
                    break;
                default:
                    System.out.println("erreur de logic");
                    break;
            }
            UpGUI();
        }
    }

    public OneOFive() {
        nom1 = JOptionPane.showInputDialog(null, "Nom du Joueur 1");
        nom2 = JOptionPane.showInputDialog(null, "Nom du Joueur 2");
        gui();
    }

    public void gui() {
        frame = new JFrame("One-O-Five");
        frame.setSize(620, 620);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        panel = new JPanel(new GridLayout(2, 1));
        panel2 = new JPanel(new BorderLayout());

        b1 = new JButton("Roule");
        panel2.add(b1, BorderLayout.NORTH);
        b2 = new JButton("Pari");
        b2.setVisible(false);
        panel2.add(b2, BorderLayout.SOUTH);
        s1 = new JLabel("Score " + nom1 + " | Valeur du dé:" + numD1 + "/6 | Montant de dé:" + monD1 + "/5");
        panel.add(s1);
        l1 = new JLabel(nom1 + " Tu as rouler un: ");
        panel2.add(l1, BorderLayout.WEST);
        s2 = new JLabel("Score " + nom2 + " | Valeur du dé:" + numD2 + "/6 | Montant de dé:" + monD2 + "/5");
        panel.add(s2);
        l2 = new JLabel(nom2 + " Tu as rouler un: ");
        panel2.add(l2, BorderLayout.EAST);
        frame.add(panel2);
        panel2.add(panel, BorderLayout.CENTER);
        frame.add(panel2);

        Roule1 u = new Roule1();
        b1.addActionListener(u);
        Pari d = new Pari();
        b2.addActionListener(d);
    }

    public int Roule() {
        return ((int) (Math.random() * 6 + 1));
    }

    public int NumUp(int monD, int numD, String nom) {
        if (monD == 5) {
            if (numD == 6) {
                Fini(nom);
            } else {
                monD = 0;
                numD++;
            }
            System.out.println("valeur nouveau:" + numD);
        } else {
            System.out.println("montant nouveau:" + monD);
        }
        return numD;
    }

    public int NewMon(int monD) {
        if (monD == 5) {
            monD = 0;
        }
        return monD;
    }

    public void PariNon(int numD) {
        if (numD != 1 && numD != 6) {
            b2.setVisible(true);
        }else{
        b2.setVisible(false);
        }
    }

    public void UpGUI() {
        s1.setText("Score " + nom1 + " | Valeur du dé:" + numD1 + "/6 | Montant de dé:" + monD1 + "/5");
        s2.setText("Score " + nom2 + " | Valeur du dé:" + numD2 + "/6 | Montant de dé:" + monD2 + "/5");
        if (tour != 1) {
            l1.setText(nom1 + " Tu as rouler un: " + rouleV);
            l2.setText(nom2 + " Tu as rouler un: ");
        } else if (tour != 2) {
            l2.setText(nom2 + " Tu as rouler un: " + rouleV);
            l1.setText(nom1 + " Tu as rouler un: ");
        } else {
            System.out.println("erreur");
        }
    }

    public void Fini(String nom) {
        int i = JOptionPane.showConfirmDialog(null, "FELICITATION " + nom + "! TU AS GAGNER! Voulez vous jouer encore?");

        if (i == 0) {
            frame.dispose();
            tour = 1;
            numD1 = 1;
            numD2 = 1;
            monD1 = 0;
            monD2 = 0;
            rouleV = 0;
            nom1 = JOptionPane.showInputDialog(null, "Nom du Joueur 1");
            nom2 = JOptionPane.showInputDialog(null, "Nom du Joueur 2");
            gui();
        } else {
            frame.dispose();
        }
    }

    public static void main(String args[]) {
        new OneOFive();
    }
}
