
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author KhangNguyen
 */
public class OneOFive {

    private JFrame frame;
    private JPanel[] p = new JPanel[20];
    private JLabel[][] l = new JLabel[2][4];
    private JButton[] b = new JButton [2];
    private int tour = 1, numD1 = 1, numD2 = 1, monD1 = 0, monD2 = 0, rouleV;
    public static String nom1, nom2;

    public class Roule1 implements ActionListener {

        public void actionPerformed(ActionEvent u) {
            rouleV = (Roule());

            switch (tour) {
                case 1:
                    if (rouleV == numD1) {
                        monD1++;
                        numD1 = NumUp(monD1, numD1, nom1);
                        monD1 = NewMon(monD1);
                    } else {
                        System.out.println("Pas le bon valeur1");
                    }
                    tour = 2;
                    PariNon(numD2);
                    break;
                case 2:
                    if (rouleV == numD2) {
                        monD2++;
                        numD2 = NumUp(monD2, numD2, nom2);
                        monD2 = NewMon(monD2);
                    } else {
                        System.out.println("Pas le bon valeur2");
                    }
                    tour = 1;
                    PariNon(numD1);
                    break;
                default:
                    System.out.println("erreur de logic");
                    break;
            }
            System.out.println("Tour du joueur" + tour);
            UpGUI();
        }

    }

    public class Pari implements ActionListener {

        public void actionPerformed(ActionEvent d) {
            rouleV = (Roule());

            switch (tour) {
                case 1:
                    if (rouleV == numD1) {
                        monD1 = 0;
                        numD1++;
                    } else {
                        monD1 = 0;
                        numD1--;
                        System.out.println("Pas le bon valeur1");
                    }
                    tour = 2;
                    PariNon(numD2);
                    break;
                case 2:
                    if (rouleV == numD2) {
                        monD2++;
                        numD2++;
                    } else {
                        monD2 = 0;
                        numD2--;
                        System.out.println("Pas le bon valeur2");
                    }
                    tour = 1;
                    PariNon(numD1);
                    break;
                default:
                    System.out.println("erreur de logic");
                    break;
            }
            UpGUI();
        }
    }

    public OneOFive() {
        nom1 = JOptionPane.showInputDialog(null, "Nom du Joueur 1");
        nom2 = JOptionPane.showInputDialog(null, "Nom du Joueur 2");
        gui();
    }

    public void gui() {
        frame = new JFrame("One-O-Five");
        frame.setSize(620, 320);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        b[0] = new JButton("Roule");
        b[1] = new JButton("Pari");
        b[1].setVisible(false);
        l[0][0] = new JLabel("Nom: " + nom1);
        l[0][0].setFont(l[0][0].getFont().deriveFont (24f));
        l[0][1] = new JLabel("Valeur du dé voulu: " + numD1 + "/6");
        l[0][2] = new JLabel("Montant de cette valeur roulé: " + monD1 + "/5");
        l[0][3] = new JLabel(nom1 + " Tu as rouler un: ");
        l[1][0] = new JLabel("Nom: " + nom2);
        l[1][0].setFont(l[1][0].getFont().deriveFont (24f));
        l[1][1] = new JLabel("Valeur du dé voulu: " + numD2 + "/6");
        l[1][2] = new JLabel("Montant de cette valeur roulé: " + monD2 + "/5");
        l[1][3] = new JLabel(nom2 + " Tu as rouler un: ");
        
        
        //North
        p[1] = new JPanel(new GridLayout(1, 1));
        p[2] = new JPanel(new FlowLayout());
        p[1].add(p[2]);
        
        //Center
        p[3] = new JPanel(new GridLayout(2, 1));
        p[4] = new JPanel(new FlowLayout());
        p[4].add(b[0]);
        p[3].add(p[4]);
        p[5] = new JPanel(new FlowLayout());
        p[5].add(b[1]);
        p[3].add(p[5]);
        
        //South
        p[6] = new JPanel(new GridLayout(1, 1));
        p[7] = new JPanel(new FlowLayout());
        p[6].add(p[7]);
        
        //West
        p[8] = new JPanel(new BorderLayout());
        p[8].setBorder(BorderFactory.createLineBorder(Color.black));
        p[9] = new JPanel(new FlowLayout());
        p[9].add(l[0][0]);
        p[8].add(p[9], BorderLayout.NORTH);
        p[10] = new JPanel(new GridLayout (3,1));
        p[11] = new JPanel(new FlowLayout());
        p[11].add(l[0][1]);
        p[10].add(p[11]);
        p[12] = new JPanel(new FlowLayout());
        p[12].add(l[0][2]);
        p[10].add(p[12]);
        p[13] = new JPanel(new FlowLayout());
        p[13].add(l[0][3]);
        p[10].add(p[13]);
        p[8].add(p[10], BorderLayout.CENTER);
        
        //East
        p[14] = new JPanel(new BorderLayout());
        p[14].setBorder(BorderFactory.createLineBorder(Color.black));
        p[15] = new JPanel(new FlowLayout());
        p[15].add(l[1][0]);
        p[14].add(p[15], BorderLayout.NORTH);
        p[16] = new JPanel(new GridLayout (3,1));
        p[17] = new JPanel(new FlowLayout());
        p[17].add(l[1][1]);
        p[16].add(p[17]);
        p[18] = new JPanel(new FlowLayout());
        p[18].add(l[1][2]);
        p[16].add(p[18]);
        p[19] = new JPanel(new FlowLayout());
        p[19].add(l[1][3]);
        p[16].add(p[19]);
        p[14].add(p[16], BorderLayout.CENTER);
        
        //JFrame
        p[0] = new JPanel(new BorderLayout());
        p[0].add(p[1], BorderLayout.NORTH);
        p[0].add(p[3], BorderLayout.CENTER);
        p[0].add(p[6], BorderLayout.SOUTH);
        p[0].add(p[8], BorderLayout.WEST);
        p[0].add(p[14], BorderLayout.EAST);
        frame.add(p[0]);
        
        Roule1 u = new Roule1();
        b[0].addActionListener(u);
        Pari d = new Pari();
        b[1].addActionListener(d);
    }

    public int Roule() {
        return ((int) (Math.random() * 5 + 1));
    }

    public int NumUp(int monD, int numD, String nom) {
        if (monD == 5) {
            if (numD == 6) {
                Fini(nom);
            } else {
                monD = 0;
                numD++;
            }
            System.out.println("valeur nouveau:" + numD);
        } else {
            System.out.println("montant nouveau:" + monD);
        }
        return numD;
    }

    public int NewMon(int monD) {
        if (monD == 5) {
            monD = 0;
        }
        return monD;
    }

    public void PariNon(int numD) {
        if (numD != 1 && numD != 6) {
            b[1].setVisible(true);
        }else{
        b[1].setVisible(false);
        }
    }

    public void UpGUI() {
        l[0][0].setText("Nom: " + nom1);
        l[0][1].setText("Valeur du dé voulu: " + numD1 + "/6");
        l[0][2].setText("Montant de cette valeur roulé: " + monD1 + "/5");
        l[1][0].setText("Nom: " + nom2);
        l[1][1].setText("Valeur du dé voulu: " + numD2 + "/6");
        l[1][2].setText("Montant de cette valeur roulé: " + monD2 + "/5");
        if (tour != 1) {
            l[0][3].setText(nom1 + " Tu as rouler un: " + rouleV);
            l[1][3].setText(nom2 + " Tu as rouler un: ");
        } else if (tour != 2) {
            l[1][3].setText(nom2 + " Tu as rouler un: " + rouleV);
            l[0][3].setText(nom1 + " Tu as rouler un: ");
        } else {
            System.out.println("erreur");
        }
    }

    public void Fini(String nom) {
        int i = JOptionPane.showConfirmDialog(null, "FELICITATION " + nom + "! TU AS GAGNER! Voulez vous jouer encore?");

        if (i == 0) {
            frame.dispose();
            tour = 1;
            numD1 = 1;
            numD2 = 1;
            monD1 = 0;
            monD2 = 0;
            rouleV = 0;
            gui();
        } else {
            frame.dispose();
        }
    }

    public static void main(String args[]) {
        new OneOFive();
    }
}
