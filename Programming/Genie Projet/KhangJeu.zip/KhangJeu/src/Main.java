
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class Main {

    public static int i = 0;
    public static String[] args = {};

    public static void main(String args[]) {
        do {
            String strI = JOptionPane.showInputDialog(null, "Combien de Personnes vont jouer?(minimum 2)");
            if (strI == null) {
                System.exit(0);
            }
            try{
            i = Integer.parseInt(strI);
            }catch (NumberFormatException e){
            JOptionPane.showMessageDialog(null, strI+" n'est pas un nombre.");
            }
        } while (i < 2);
        OneOFive.main(args);
    }
}
