
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class Crash {

    public int i = 10000000;//Crucial, ceci est le montant de gens qui joue, et cela decideras tous les dimensions et Jbuttons
    public boolean debogue = true;//veut tu deboguer esteur?
    public JFrame[] frame = new JFrame[5];
    public JTextArea text = new JTextArea();// le text field pour les reglement
    public JPanel[] m = new JPanel[5];// m est le Jpanel Sud pour les gens et nord pour le bouton, m2 est le flow pour le boutton roule et m3 pour tous les joueurs
    //il est i+1 car je nutilise pas 0, je commence a 1 et donc tous se décale
    public JPanel[][] p = new JPanel[i + 1][7];//1 Jpanel par joueur et s est pour les sous cat/gorie
    public JLabel[][] l = new JLabel[i + 1][4]; // JLabel [0 est joueur 1 et 1 joueur 2][nom,valeur du dé voulu, montant de ces dés rouler, valeur du dé rouler]
    public JButton[] b = new JButton[i + 2]; // 0 = Roule et i = pari, i+1 = le bouton pour les regles
    public int[] numD = new int[i + 1], monD = new int[i + 1], rouleV = new int[i + 1];//numD est le valeur du dé voulu, monD est le montant de dé de cet valeur rouler, et rouleV est le valeur du dé rouler (chaque joueur  a leur monD numD et valeurD respective)
    public boolean[] egale = new boolean[i + 1];// ceci est un boolean qui dit si 
    public String[] nom = new String[i + 1];//le nom de chaque personne

    //debug
    public void D(String e) {
        if (debogue == true) {
            System.out.println(e);
        }
    }

    public void gui() {
        D("Construction du IUG");
        for (int k = 1; k <= 5; k++) {
            for (int x = 1; x <= i; x++) {
                D("Lances les valeurs de " + x);
                numD[x] = 1;
                monD[x] = 0;
                rouleV[x] = 0;
            }

            frame[k] = new JFrame("One-O-Five");

            D("Set Size du Window");
            frame[k].setSize(200 + (350 * ((int) Math.sqrt(i))), (100 + (325 * ((int) Math.sqrt(i)))));
            frame[k].setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame[k].setLocationRelativeTo(null);

            for (int x = 1; x <= i; x++) {
                D("Creation du GUI de " + x);
                b[x] = new JButton("Pari");
                l[x][0] = new JLabel("Nom: " + nom[x]);
                l[x][0].setFont(l[x][0].getFont().deriveFont(24f));
                l[x][1] = new JLabel("Valeur du dé voulu: " + numD[x]);
                l[x][2] = new JLabel("Montant de cette valeur roulé: " + monD[x] + "/5");
                l[x][3] = new JLabel(nom[x] + " Tu as rouler un: ");
            }

            //NORTH
            b[0] = new JButton("Roule");
            m[1] = new JPanel(new FlowLayout());
            m[1].add(b[0]);

            //CENTER
            m[2] = new JPanel(new GridLayout(0, ((int) Math.sqrt(i))));
            for (int x = 1; x <= i; x++) {
                p[x][0] = new JPanel(new BorderLayout());
                p[x][0].setBorder(BorderFactory.createLineBorder(Color.black));
                p[x][1] = new JPanel(new FlowLayout());
                p[x][1].add(l[x][0]);
                p[x][1].setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.black));
                p[x][1].setBackground(Color.green);
                p[x][0].add(p[x][1], BorderLayout.NORTH);
                p[x][2] = new JPanel(new GridLayout(0, 1));
                p[x][3] = new JPanel(new FlowLayout());
                p[x][3].add(l[x][1]);
                p[x][2].add(p[x][3]);
                p[x][4] = new JPanel(new FlowLayout());
                p[x][4].add(l[x][2]);
                p[x][2].add(p[x][4]);
                p[x][5] = new JPanel(new FlowLayout());
                p[x][5].add(l[x][3]);
                p[x][2].add(p[x][5]);
                p[x][6] = new JPanel(new FlowLayout());
                p[x][6].add(b[x]);
                p[x][2].add(p[x][6]);
                p[x][0].add(p[x][2], BorderLayout.CENTER);
                m[2].add(p[x][0]);
            }

            //SOUTH
            m[3] = new JPanel(new BorderLayout());
            b[i + 1] = new JButton("?");
            m[3].add(b[i + 1], BorderLayout.EAST);

            m[0] = new JPanel(new BorderLayout());
            m[0].add(m[1], BorderLayout.NORTH);
            m[0].add(m[2], BorderLayout.CENTER);
            m[0].add(m[3], BorderLayout.SOUTH);
            frame[k].add(m[0]);
            frame[k].setVisible(true);

            //Boutton de roule peser
            b[0].addActionListener(
                    new ActionListener() {
                public void actionPerformed(ActionEvent u) {
                }
            }
            );

            //boutton de pari peser
            for (int x = 1; x <= i; x++) {
                int y = x;
                b[x].addActionListener(
                        new ActionListener() {
                    public void actionPerformed(ActionEvent u) {
                    }
                }
                );
            }

        }
    }
    public Crash() {
        gui();
    }

    public static void main(String args[]) {
        new Crash();
    }
}
