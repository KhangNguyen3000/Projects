
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class OneOFive {

    public int i = Main.i;//Crucial, ceci est le montant de gens qui joue, et cela decideras tous les dimensions et Jbuttons
    public boolean debogue = true;//veut tu deboguer esteur?
    public JFrame frame;
    public JTextArea text = new JTextArea();// le text field pour les reglement
    public JPanel[] m = new JPanel[5];// m est le Jpanel Sud pour les gens et nord pour le bouton, m2 est le flow pour le boutton roule et m3 pour tous les joueurs
    //il est i+1 car je nutilise pas 0, je commence a 1 et donc tous se décale
    public JPanel[][] p = new JPanel[i + 1][7];//1 Jpanel par joueur et s est pour les sous cat/gorie
    public JLabel[][] l = new JLabel[i + 1][4]; // JLabel [0 est joueur 1 et 1 joueur 2][nom,valeur du dé voulu, montant de ces dés rouler, valeur du dé rouler]
    public JButton[] b = new JButton[i + 2]; // 0 = Roule et i = pari, i+1 = le bouton pour les regles
    public int[] numD = new int[i + 1], monD = new int[i + 1], rouleV = new int[i + 1];//numD est le valeur du dé voulu, monD est le montant de dé de cet valeur rouler, et rouleV est le valeur du dé rouler (chaque joueur  a leur monD numD et valeurD respective)
    public boolean[] egale = new boolean[i + 1];// ceci est un boolean qui dit si 
    public String[] nom = new String[i + 1];//le nom de chaque personne

    //debug
    public void D(String e) {
        if (debogue == true) {
            System.out.println(e);
        }
    }

    /*ceci est le constructeur du jeu, ce constructeur change de taille par nombre de personne qui joue.
    utilise la racine carréé plus proche du nombre de joueur (elévé a luniter la plus haut)
    pour que la fenetre soit pas un fenetre trops longue mais plus prche d'un carrée. le grid layout a le nombre <
    de collonnes egale a la racine carrée du nombre de joueurs et elle utilise un nombre de rangée infini (chaque grid est 
    un joueur est donc il y a un for loop pour créer chaque joueur)*/
    public void gui() {
        D("Construction du IUG");
        
        for (int x = 1; x <= i; x++) {
            D("Lances les valeurs de " + x);
            numD[x] = 1;
            monD[x] = 0;
            rouleV[x] = 0;
        }

        frame = new JFrame("One-O-Five");

        D("Set Size du Window");
        frame.setSize(200 + (350 * ((int) Math.sqrt(i))), (100 + (325 * ((int) Math.sqrt(i)))));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        for (int x = 1; x <= i; x++) {
            D("Creation du GUI de " + x);
            b[x] = new JButton("Pari");
            l[x][0] = new JLabel("Nom: " + nom[x]);
            l[x][0].setFont(l[x][0].getFont().deriveFont(24f));
            l[x][1] = new JLabel("Valeur du dé voulu: " + numD[x]);
            l[x][2] = new JLabel("Montant de cette valeur roulé: " + monD[x] + "/5");
            l[x][3] = new JLabel(nom[x] + " Tu as rouler un: ");
        }

        //NORTH
        b[0] = new JButton("Roule");
        m[1] = new JPanel(new FlowLayout());
        m[1].add(b[0]);

        //CENTER
        m[2] = new JPanel(new GridLayout(0, ((int) Math.sqrt(i))));
        for (int x = 1; x <= i; x++) {
            p[x][0] = new JPanel(new BorderLayout());
            p[x][0].setBorder(BorderFactory.createLineBorder(Color.black));
            p[x][1] = new JPanel(new FlowLayout());
            p[x][1].add(l[x][0]);
            p[x][1].setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.black));
            p[x][1].setBackground(Color.green);
            p[x][0].add(p[x][1], BorderLayout.NORTH);
            p[x][2] = new JPanel(new GridLayout(0, 1));
            p[x][3] = new JPanel(new FlowLayout());
            p[x][3].add(l[x][1]);
            p[x][2].add(p[x][3]);
            p[x][4] = new JPanel(new FlowLayout());
            p[x][4].add(l[x][2]);
            p[x][2].add(p[x][4]);
            p[x][5] = new JPanel(new FlowLayout());
            p[x][5].add(l[x][3]);
            p[x][2].add(p[x][5]);
            p[x][6] = new JPanel(new FlowLayout());
            p[x][6].add(b[x]);
            p[x][2].add(p[x][6]);
            p[x][0].add(p[x][2], BorderLayout.CENTER);
            m[2].add(p[x][0]);
        }

        //SOUTH
        m[3] = new JPanel(new BorderLayout());
        b[i + 1] = new JButton("?");
        m[3].add(b[i + 1], BorderLayout.EAST);

        m[0] = new JPanel(new BorderLayout());
        m[0].add(m[1], BorderLayout.NORTH);
        m[0].add(m[2], BorderLayout.CENTER);
        m[0].add(m[3], BorderLayout.SOUTH);
        frame.add(m[0]);
        frame.setVisible(true);

        //Boutton de roule peser
        b[0].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Boutton de roule peser");
                BPeser();
            }
        }
        );

        //boutton de pari peser
        for (int x = 1; x <= i; x++) {
            int k = x;
            b[x].addActionListener(
                    new ActionListener() {
                public void actionPerformed(ActionEvent u) {
                    D("Boutton de roule peser");
                    BPPeser(k);
                }
            }
            );
        }

        //Boutton de reglements peser
        b[i + 1].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Boutton de HUH peser");
                BHUHPeser();
            }
        }
        );

    }

    /*Ceci est le methode lorsque les gens ne savent pas comment jouer ils vont peser, ce methode est simplement une JFrame qui
    donne un Jtezxtfield avec les reglements du jeu (haha cest 100% pas copy paster du google docs)*/
    public void BHUHPeser() {
        frame = new JFrame("Les Reglements");
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setSize(800, 1000);
        frame.setLocationRelativeTo(null);
        m[4] = new JPanel(new GridLayout(1, 1));

        text = new JTextArea("Explication\n"
                + "(2 a un nombre infini de joueurs)Le but du jeu est de se rendre à 30 points. Pour gagner des points, les joueurs doit commencer en roulant un dé de valeur 1. Tous joueurs qui roule un valeur de 1 gagne un point. (Tout le monde roule en même temps) les joueurs qui ne roule pas un 1 ne gagne pas un point. Après avoir rouler le valeur 1 cinq fois, le joueur continue à la prochaine niveau. Après avoir roulé 1 cinq fois, le joueur doit maintenant essayer de rouler 2 cinq fois. Ceci se répète jusqu'à quand un joueur se rend à cinq roule de valeur 6. Un joueur peut se trouver au 3ieme niveau lorsqu'un autre joueur de trouve au premier niveau. Tout joueur a leurs point indépendant.\n"
                + "\n"
                + "Pari\n"
                + "Tout Joueur peut parier 1 fois par JEU. Lorsqu’un joueur pari, TOUS les joueurs roule. Les joueurs qui ont un valeur rouler égale ou plus bas au joueur qui a parier, perdent leur points. Le montant de point perdue dépend du montant de point de chaque joueur. Par exemple, si tu est au 2ieme niveau ou plus haut, tu tombe d'un niveau. (joueur qui est au niveau 3 tombe au niveau 2 avec et doit rouler la valeur 2 cinq fois encore). Un joueur au premiere niveau doit simplement re-rouler la valeur 1 cinq fois encore.\n"
                + "\n"
                + "Exceptions\n"
                + "Si il n’y a personne qui a rouler la valeur voulu. Les personnes avec les plus haut valeurs gagne.\n"
                + "\n"
                + "\n"
                + "X joue contre Y\n"
                + "X roule un 1 (1/5)\n"
                + "Y roule un 5 (0/5)\n"
                + "X roule un 1 (2/5)\n"
                + "Y roule un 1 (1/5)\n"
                + "X roule un 1 (3/5)\n"
                + "Y roule un 4 (1/5)\n"
                + "X roule un 1 (4/5)\n"
                + "Y roule un 3 (1/5)\n"
                + "X roule un 1 (5/5)\n"
                + "\n"
                + "X est a valeur = 2\n"
                + "Y roule un 2 (1/5)\n"
                + "X roule un 3 (0/5)\n"
                + "Y roule un 2 (1/5)\n"
                + "X roule un 2 (1/5)\n"
                + "Y roule un 1 (2/5)\n"
                + "X roule un 2 (2/5)\n"
                + "Y roule un 2 (2/5)\n"
                + "X roule un 2 (3/5)\n"
                + "Y roule un 1 (3/5)\n"
                + "X roule un 2 (4/5)\n"
                + "Y roule un 1 (4/5)\n"
                + "X roule un 2 (5/5)\n"
                + "\n"
                + "X est a valeur = 3\n"
                + "Y roule un 1 (5/5)\n"
                + "Y est a valeur = 2\n"
                + "X roule un 5  a pari \n"
                + "Y roule un 3\n"
                + "Y est à valeur = 1\n"
                + "X roule un 4  a pari (5/5)\n"
                + "X est a valeur = 5\n"
                + "Y roule un 5 (0/5)\n"
                + "X roule un 5  à pari (5/5)\n"
                + "X est a valeur = 6\n"
                + "Y roule un 1 (1/5)\n"
                + "X roule un 6 (1/5)\n"
                + "Y roule un 5 (0/5)\n"
                + "X roule un 6 (2/5)\n"
                + "Y roule un 1 (1/5)\n"
                + "X roule un 6 (3/5)\n"
                + "Y roule un 4 (1/5)\n"
                + "X roule un 6 (4/5)\n"
                + "Y roule un 3 (1/5)\n"
                + "X roule un 6 (5/5)");

        text.setLineWrap(true);
        m[4].add(text);
        frame.add(m[4]);
        text.setEditable(false);
        frame.setVisible(true);
    }

    //ceci est simplement pour organiser le prgramme, elle aide suivre le code
    public OneOFive() {
        DemandeNom();
        gui();
    }

    //ceci demande un nom pour chaque joueur est le sauve dans le var nom[x]
    public void DemandeNom() {
        D("demande pour les noms");

        for (int x = 1; x <= i; x++) {
            nom[x] = JOptionPane.showInputDialog(null, "Nom du Joueur " + x);
            if (nom[x] == null) {
                System.exit(0);
            }
        }
    }

    /*ceci est la methode lorsque le boutton de roule est peser, elle check si le nombre rouler est égale au nombre voulu et
    ensuite chnage le boolean de ce joueur a vrais(pour chaque joueur). ensuite le methode Ego sa check si au moins un des 
    joueurs a rouler la valeur qu'il voulaient. ensuite upGUI sa update le GUI*/
    public void BPeser() {
        D("Fonctionnement du roule");

        for (int x = 1; x <= i; x++) {
            rouleV[x] = Roule();
            if (rouleV[x] == numD[x]) {
                D("Numero egale valeur voulu");
                Egale(x);
            } else {
                D("pas le bon valeur rouler");
                p[x][1].setBackground(Color.red);
                egale[x] = false;
            }
        }
        D("Fini un tour");
        Ego();
        UpGUI();
    }

    /*ceci est le boutton de pari, ce code roule le dé pour le personnne qui a peser le boutton, ensuite 
    il roule le dé pouir chaque joueur sauf le joueur qui a parier. Ensuite si le valeur d'un joueur est
    plus grand que le joueur qui a parier, il ne perd pas de points, si il est egale ou plus petit, il perde un 
    niveau, donc le valeur du dé voulu tombe, si la valeur voulu est a un (le minimum) il perde tous les montant de dé rouler et
    recommence a 0.*/
    public void BPPeser(int k) {
        D("Fonctionnement du pari");
        b[k].setEnabled(false);
        p[k][1].setBackground(Color.yellow);
        rouleV[k] = Roule();

        for (int x = 1; x <= i; x++) {
            if (x != k) {
                rouleV[x] = Roule();
                if (rouleV[x] > rouleV[k]) {
                    D("Numero egale valeur voulu");
                    p[x][1].setBackground(Color.green);
                } else {
                    D("pas le bon valeur rouler");
                    p[x][1].setBackground(Color.red);
                    if (numD[x] != 1) {
                        numD[x]--;
                    }
                    monD[x] = 0;
                }
            }
        }
        D("Fini un tour");
        UpGUI();
    }

    //ceci est le code de rouler, elle donne un variable aléatoire entre 1 et 6
    public int Roule() {
        int x = (int) (Math.random() * 6 + 1);
        return x;
    }

    /*Ceci est runner lorsque un joueur roule un valeur egale au valeur voulue. il ajoute un au 
    montant de dé rouler et ensuite run le methode qui check si il augment de 1 niveau
    (donc le valeur voulu augment par 1)*/
    public void Egale(int x) {
        p[x][1].setBackground(Color.green);
        monD[x]++;
        egale[x] = true;
        NumUp(x);
    }

    /*ceci check si le montant de dé rouler est egale a 5, si oui remet le montant a 0 et augment le valeur voulu.
    si non, fait rien*/
    public void NumUp(int x) {
        D("Augmente de 1 valeurpeut etre");
        if (monD[x] == 5) {
            D("il a 5 valeur rouler");
            if (numD[x] == 6) {
                D("Il a rouler 6 5 fois");
                Fini(nom[x]);
            } else {
                D("Il a pas rouler la valeur 5 fois");
                monD[x] = 0;
                numD[x]++;
            }
        }
    }

    /*ceci est couru lorsque tu veut updater le GUI, pour chaque joueur il set le texte de ce qu'il a rouler, se qu'il
    veut rouler, et le montant de fois qu'il a déja rouler cela*/
    public void UpGUI() {
        D("Update GUI");
        for (int x = 1; x <= i; x++) {
            l[x][1].setText("Valeur du dé voulu: " + numD[x]);
            l[x][2].setText("Montant de cette valeur roulé: " + monD[x] + "/5");
            l[x][3].setText(nom[x] + " Tu as rouler un: " + rouleV[x]);
        }
    }

    /*ceci contre le nombre de joueurs qui ont rouler le valeur qu'ils voulaient. Si cela est 0,
    le code va prendre le plus haute valeur rouler, et ce ou ces personnes la vont gagner un point*/
    public void Ego() {
        D("est ce que tous le monde ont pas rouler leur valeur voulu");
        int intEgale = 0;
        int temp = 0;
        for (int x = 1; x <= i; x++) {
            if (egale[x] == true) {
                intEgale++;
            }
        }

        if (intEgale == 0) {
            for (int x = 1; x <= i; x++) {
                if (rouleV[x] >= temp) {
                    temp = rouleV[x];
                }
            }
            for (int x = 1; x <= i; x++) {
                if (rouleV[x] == temp) {
                    Egale(x);
                }
            }
        }
    }

    /*Ceci est runner lorsque quelqu'un gagne(il montre le nom du gagnant avec un felicitation), et si 
    les joueurs veulent ils peuvent rejouer, si non le jeu fini, (refait le GUI ca recommence le jeu)*/
    public void Fini(String nom) {
        D("Quelqu'un a Gagner");
        int i = JOptionPane.showConfirmDialog(null, "FELICITATION " + nom + "! TU AS GAGNER! Voulez vous jouer encore?");

        if (i == 0) {
            D("Recommence le Jeu");
            frame.dispose();
            gui();
        } else {
            D("Ferme le JFrame");
            frame.dispose();
        }
    }
    
    
    
    //Ceci est le main, elle commence le prgramme
    public static void main(String args[]) {
        new OneOFive();
    }
}
