
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author KhangNguyen
 */
public class OneOFive {

    public boolean debogue = false;
    private JFrame frame;
    private JPanel[] p = new JPanel[20];
    private JLabel[][] l = new JLabel[2][4];
    private JButton[] b = new JButton[2];
    private int tour = 1, numD1 = 1, numD2 = 1, monD1 = 0, monD2 = 0, rouleV;
    public static String nom1, nom2;

    public void Debogue(String e) {
        if (debogue == true) {
            System.out.println(e);
        }
    }

    public class Roule1 implements ActionListener {

        public void actionPerformed(ActionEvent u) {
            Debogue("Boutton de roule peser");
            rouleV = (Roule());

            switch (tour) {
                case 1:
                    Debogue("Player 1 a peser");
                    if (rouleV == numD1) {
                        Debogue("Numero egale valeur voulu");
                        monD1++;
                        numD1 = NumUp(monD1, numD1, nom1);
                        monD1 = NewMon(monD1);
                    } else {
                        Debogue("pas le bon valeur rouler");
                    }
                    tour = 2;
                    PariNon(numD2);
                    break;
                case 2:
                    Debogue("player 2 a peser");
                    if (rouleV == numD2) {
                        Debogue("Numero egale a valeur voulu");
                        monD2++;
                        numD2 = NumUp(monD2, numD2, nom2);
                        monD2 = NewMon(monD2);
                    } else {
                        Debogue("pas le bon valeur rouler");
                    }
                    tour = 1;
                    PariNon(numD1);
                    break;
                default:
                    Debogue("Pas le player 1 ou 2 qui a peser?");
                    break;
            }
            Debogue("Change de joueur");
            UpGUI();
        }

    }

    public class Pari implements ActionListener {

        public void actionPerformed(ActionEvent d) {
            Debogue("Boutton pari Rouler");
            rouleV = (Roule());

            switch (tour) {
                case 1:
                    Debogue("Player 1 a rouler");
                    if (rouleV == numD1) {
                        Debogue("valeur rouler est valeur voulue");
                        monD1 = 0;
                        numD1++;
                    } else {
                        Debogue("Valeur rouler est pas valeur voulue");
                        monD1 = 0;
                        numD1--;
                    }
                    tour = 2;
                    PariNon(numD2);
                    break;
                case 2:
                    Debogue("Player 2 joue");
                    if (rouleV == numD2) {
                        Debogue("valeur rouler est valeur voulu");
                        monD2++;
                        numD2++;
                    } else {
                        Debogue("Valeur rouler est pas valeur voulu");
                        monD2 = 0;
                        numD2--;
                    }
                    tour = 1;
                    PariNon(numD1);
                    break;
                default:
                    Debogue("pas joueur 1 ou joueur 2 qui a jouer?");
                    break;
            }
            UpGUI();
        }
    }

    public OneOFive() {
        Debogue("Demande pour les nom");
        nom1 = JOptionPane.showInputDialog(null, "Nom du Joueur 1");
        nom2 = JOptionPane.showInputDialog(null, "Nom du Joueur 2");
        gui();
    }

    public void gui() {
        Debogue("Run le contrusteur de JFrame");
        frame = new JFrame("One-O-Five");
        frame.setSize(620, 320);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        b[0] = new JButton("Roule");
        b[1] = new JButton("Pari");
        b[1].setVisible(false);
        l[0][0] = new JLabel("Nom: " + nom1);
        l[0][0].setFont(l[0][0].getFont().deriveFont(24f));
        l[0][1] = new JLabel("Valeur du dé voulu: " + numD1 + "/6");
        l[0][2] = new JLabel("Montant de cette valeur roulé: " + monD1 + "/5");
        l[0][3] = new JLabel(nom1 + " Tu as rouler un: ");
        l[1][0] = new JLabel("Nom: " + nom2);
        l[1][0].setFont(l[1][0].getFont().deriveFont(24f));
        l[1][1] = new JLabel("Valeur du dé voulu: " + numD2 + "/6");
        l[1][2] = new JLabel("Montant de cette valeur roulé: " + monD2 + "/5");
        l[1][3] = new JLabel(nom2 + " Tu as rouler un: ");

        //North
        p[1] = new JPanel(new GridLayout(1, 1));
        p[2] = new JPanel(new FlowLayout());
        p[1].add(p[2]);

        //Center
        p[3] = new JPanel(new GridLayout(2, 1));
        p[4] = new JPanel(new FlowLayout());
        p[4].add(b[0]);
        p[3].add(p[4]);
        p[5] = new JPanel(new FlowLayout());
        p[5].add(b[1]);
        p[3].add(p[5]);

        //South
        p[6] = new JPanel(new GridLayout(1, 1));
        p[7] = new JPanel(new FlowLayout());
        p[6].add(p[7]);

        //West
        p[8] = new JPanel(new BorderLayout());
        p[8].setBorder(BorderFactory.createLineBorder(Color.black));
        p[9] = new JPanel(new FlowLayout());
        p[9].add(l[0][0]);
        p[8].add(p[9], BorderLayout.NORTH);
        p[10] = new JPanel(new GridLayout(3, 1));
        p[11] = new JPanel(new FlowLayout());
        p[11].add(l[0][1]);
        p[10].add(p[11]);
        p[12] = new JPanel(new FlowLayout());
        p[12].add(l[0][2]);
        p[10].add(p[12]);
        p[13] = new JPanel(new FlowLayout());
        p[13].add(l[0][3]);
        p[10].add(p[13]);
        p[8].add(p[10], BorderLayout.CENTER);

        //East
        p[14] = new JPanel(new BorderLayout());
        p[14].setBorder(BorderFactory.createLineBorder(Color.black));
        p[15] = new JPanel(new FlowLayout());
        p[15].add(l[1][0]);
        p[14].add(p[15], BorderLayout.NORTH);
        p[16] = new JPanel(new GridLayout(3, 1));
        p[17] = new JPanel(new FlowLayout());
        p[17].add(l[1][1]);
        p[16].add(p[17]);
        p[18] = new JPanel(new FlowLayout());
        p[18].add(l[1][2]);
        p[16].add(p[18]);
        p[19] = new JPanel(new FlowLayout());
        p[19].add(l[1][3]);
        p[16].add(p[19]);
        p[14].add(p[16], BorderLayout.CENTER);

        //JFrame
        p[0] = new JPanel(new BorderLayout());
        p[0].add(p[1], BorderLayout.NORTH);
        p[0].add(p[3], BorderLayout.CENTER);
        p[0].add(p[6], BorderLayout.SOUTH);
        p[0].add(p[8], BorderLayout.WEST);
        p[0].add(p[14], BorderLayout.EAST);
        frame.add(p[0]);

        Roule1 u = new Roule1();
        b[0].addActionListener(u);
        Pari d = new Pari();
        b[1].addActionListener(d);
    }

    public int Roule() {
        Debogue("Roule et donne valeur aléatoir");
        return ((int) (Math.random() * 6 + 1));
    }

    public int NumUp(int monD, int numD, String nom) {
        Debogue("Augmente de 1 valeurpeut etre");
        if (monD == 5) {
            Debogue("il a 5 valeur rouler");
            if (numD == 6) {
                Debogue("Il a rouler 6 5 fois");
                Fini(nom);
            } else {
                Debogue("Il a pas rouler la valeur 5 fois");
                monD = 0;
                numD++;
            }
        }
        return numD;
    }

    public int NewMon(int monD) {
        Debogue("Si il a rouler la valeur 5 fois retourne a 0");
        if (monD == 5) {
            monD = 0;
        }
        return monD;
    }

    public void PariNon(int numD) {
        Debogue("Peut til parrier?");
        if (numD != 1 && numD != 6) {
            Debogue("Il peut parrier");
            b[1].setVisible(true);
        } else {
            Debogue("Il peut pas parrier");
            b[1].setVisible(false);
        }
    }

    public void UpGUI() {
        Debogue("Update GUI");
        l[0][0].setText("Nom: " + nom1);
        l[0][1].setText("Valeur du dé voulu: " + numD1 + "/6");
        l[0][2].setText("Montant de cette valeur roulé: " + monD1 + "/5");
        l[1][0].setText("Nom: " + nom2);
        l[1][1].setText("Valeur du dé voulu: " + numD2 + "/6");
        l[1][2].setText("Montant de cette valeur roulé: " + monD2 + "/5");
        if (tour != 1) {
            Debogue("Joueur 1 a rouler");
            l[0][3].setText(nom1 + " Tu as rouler un: " + rouleV);
            l[1][3].setText(nom2 + " Tu as rouler un: ");
        } else if (tour != 2) {
            Debogue("joueur 2 a rouler");
            l[1][3].setText(nom2 + " Tu as rouler un: " + rouleV);
            l[0][3].setText(nom1 + " Tu as rouler un: ");
        } else {
            Debogue("pas joueur 1 ou 2 a rouler");
        }
    }

    public void Fini(String nom) {
        Debogue("Quelqu'un a Gagner");
        int i = JOptionPane.showConfirmDialog(null, "FELICITATION " + nom + "! TU AS GAGNER! Voulez vous jouer encore?");

        if (i == 0) {
            frame.dispose();
            tour = 1;
            numD1 = 1;
            numD2 = 1;
            monD1 = 0;
            monD2 = 0;
            rouleV = 0;
            gui();
        } else {
            frame.dispose();
        }
    }

    public static void main(String args[]) {
        new OneOFive();
    }
}
