
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author KhangNguyen
 */
public class OneOFive {

    public boolean debogue = true;
    private JFrame frame;
    private JPanel panel;
    private JLabel l1, l2, s1, s2;
    private JButton b1;
    private int tour = 1, numD1 = 1, numD2 = 1, monD1 = 0, monD2 = 0, rouleV;
    public static String nom1, nom2;

    public void Debogue(String e) {//debogue
        if (debogue == true) {
            System.out.println(e);
        }
    }

    public OneOFive() {
        Debogue("OneOFive: demande les 2 noms");
        nom1 = JOptionPane.showInputDialog(null, "Nom du Joueur 1");// demande pour nom joueur 1
        nom2 = JOptionPane.showInputDialog(null, "Nom du Joueur 2");//demande pour nom du joueur 2
        gui();//appelle au construcrteur de JFrame
    }

    public class RouleB implements ActionListener {

        public void actionPerformed(ActionEvent v) {//faire ceci lorsque le bouton est peser
            Debogue("Boutton peser");
            rouleV = (Roule());//retourne valeur aleatoire entre 1 et 6

            if (tour == 1) {//voir si il est le tour de joeur 1 ou 2
                Debogue("tour is player 1");
                if (rouleV == numD1) {//voir si la valeur rouler est la valeur voulu
                    Debogue("le numero est le valeur voulue");
                    GuiUp(tour);
                    tour = 2;//change de tour
                } else {
                    Debogue("Pas le bon valeur1");
                    tour = 2;//change de tour
                }
            } else if (tour == 2) {
                Debogue("tour is player 2");
                if (rouleV == numD1) {//voir si la valeur rouler est la valeur voulu
                    Debogue("le numéro est le valeur voulu");
                    GuiUp(tour);
                    tour = 1;//change de tour
                } else {
                    Debogue("Pas le bon valeur2");
                    tour = 1;//change de tour
                }
            } else {
                Debogue("erreur de logic");//il nest pas le tour de joueur 1 ni 2
            }
            Debogue("Tour du joueur" + tour);
            frame.dispose();// reinitialise le JFrame pour le mettre a date
            gui();
        }

    }

    public int Roule() {//retourne un nombre aleatoire entre 1 et 6
        Debogue("Donne numero alléatoir");
        return ((int) (Math.random() * 6 + 1));
    }

    public void GuiUp(int tour) {//ceci nest pas un update du GUI mais une update de l'INFORMATION du GUI
        Debogue("update GUI");
        if (tour == 1) {//si cest tour 1
            Debogue("tour encore 1");
            monD1++;//ajout 1 au montant de bonne de rouler
            if (monD1 == 5) {// si le montant de bonne de rouler est de 5 ajout 1 au valeur voulu
                Debogue("il a rouler le valeur 5 fois");
                if (numD1 == 6) {//si le montant est 6 avant l'ajout au valeur voulu il gagne
                    Debogue("il a rouler 6 5 fois");
                    Fini(nom1);//il gagne
                } else {//si non remet son montant de bonne valeur roulu a 0 et augmente la valeur voulu
                    Debogue("il augmente d'un valeur");
                    monD1 = 0;
                    numD1++;
                }
                Debogue("valeur nouveau:" + numD1);//
            } else {// si il na pas rouler la valeur 5 fois ajoute un point et continue
                Debogue("montant nouveau:" + monD1);//
            }
        } else {//si cest tour 2
            Debogue("tour encore 2");
            monD2++;//ajout 1 au montant de bonne de rouler
            if (monD2 == 5) {// si le montant de bonne de rouler est de 5 ajout 1 au valeur voulu
                Debogue("il a rouler le valeur 5 fois");
                if (numD2 == 6) {//si le montant est 6 avant l'ajout au valeur voulu il gagne
                    Debogue("il a rouler 6 5 fois");
                    Fini(nom2);//il gagne
                } else {//si non remet son montant de bonne valeur roulu a 0 et augmente la valeur voulu
                    monD2 = 0;
                    numD2++;
                    Debogue("il augmente de 1 valeur");
                }
            } else {//si il na pas rouler la valeur 5 fois ajoute un point et continue
            }
        }

    }

    public void gui() {//ceci est executer a la fin de chaque tour donc chaque new object se mets a date
        Debogue("créer le fenetre");
        frame = new JFrame("One-O-Five");
        frame.setSize(350, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        panel = new JPanel(new GridLayout(5, 1));

        //Joueur 1
        b1 = new JButton("Roule");
        panel.add(b1);
        s1 = new JLabel("Score " + nom1 + " | Valeur du dé:" + numD1 + "/6 | Montant de dé:" + monD1 + "/5");
        panel.add(s1);
        l1 = new JLabel("Tu as rouler un: ");
        if (tour != 1) {//ceci est executer apres le change de tour donc si le tour est 2 cela veut dire joueur 1 viens de jouer et donc ceci dit ce qu'il a rouler
            l1 = new JLabel("Tu as rouler un: " + rouleV);
        } else {
        }

        //Joueur 2
        panel.add(l1);
        s2 = new JLabel("Score " + nom2 + " | Valeur du dé:" + numD2 + "/6 | Montant de dé:" + monD2 + "/5");
        panel.add(s2);
        l2 = new JLabel("Tu as rouler un: ");
        if (tour != 2) {//ceci est executer apres le change de tour donc si le tour est 1 cela veut dire joueur 2 viens de jouer et donc ceci dit ce qu'il a rouler
            l2 = new JLabel("Tu as rouler un: " + rouleV);
        } else {
        }
        panel.add(l2);

        frame.add(panel);

        RouleB v = new RouleB();// ajoute le fonction qui nous laisse attendre pour le paisse d'un boutton
        b1.addActionListener(v);
    }

    public void Fini(String nom) {
        int i = JOptionPane.showConfirmDialog(null, "FELICITATION " + nom + "! TU AS GAGNER! Voulez vous jouer encore?");

        if (i == 0) {//si il dit oui remet tous les valeurs a leur original
            frame.dispose();
            tour = 1;
            numD1 = 1;
            numD2 = 1;
            monD1 = 0;
            monD2 = 0;
            rouleV = 0;
            gui();
        } else {
            frame.dispose();//si non ferme le program
        }
    }

    public static void main(String args[]) {
        new OneOFive();// creer nouvelle instance de ma programe
    }
}
