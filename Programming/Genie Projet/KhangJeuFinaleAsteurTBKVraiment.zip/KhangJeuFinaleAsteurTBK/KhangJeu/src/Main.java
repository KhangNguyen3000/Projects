
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class Main {

    public static int i = 0;//le nombre de joueurs
    public static String[] args = {};// un var String[] est necessaire pour runner le main du 2ieme file

    
    
    /*ceci demande combien de personne il y a et i va etre egale a ce nombre, ensuite le 2ieme fichier vas importer i de cet 
    fichier pour créer les arrays necessaire. Finalement il run le main du 2ieme fichier. si un nombre nest pas entreer 
    le prgram dit de entreer un nombre, si x ou cancel est peser ca exit.*/
    public static void main(String args[]) {
        
        do {
            String strI = JOptionPane.showInputDialog(null, "Combien de Personnes vont jouer?(minimum 2)");
            if (strI == null) {
                System.exit(0);
            }
            try{
            i = Integer.parseInt(strI);
            }catch (NumberFormatException e){
            JOptionPane.showMessageDialog(null, strI+" n'est pas un nombre.");
            }
        } while (i < 2);
        
        OneOFive.main(args);
    }
}
