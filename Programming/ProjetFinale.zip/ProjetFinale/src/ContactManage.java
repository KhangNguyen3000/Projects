
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import javax.swing.*;

/**
 *
 * @author KhangNguyen
 */
public class ContactManage {

    /*Import le list et file du class Main*/
    private List<Info> contactList = Main.contactList;
    private File file = Main.file;
    int x, y;

    public boolean debug = true;
    private JFrame frame, frame2, frame3, frame4, frame5;
    private JTextArea textA = new JTextArea();
    /*xxxxx [JFrame #][BorderLayout Location][#]*/
    private JPanel[][][] panel = new JPanel[5][6][7];
    private JLabel[][][] label = new JLabel[5][6][6];
    private JButton[][][] boutton = new JButton[5][6][6];
    private JTextField[][][] textF = new JTextField[5][6][6];


    /*Debug*/
    public void D(String e) {
        if (debug == true) {
            System.out.println(e);
        }
    }

    /*Ceci trouve le nombre de pixel dans l'horizontal et le verticale et le sauve comme x et y*/
    private void Ecran() {
        D("trouve taille x et y de l'écran");
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
        Rectangle rect = defaultScreen.getDefaultConfiguration().getBounds();
        x = (int) rect.getMaxX();
        y = (int) rect.getMaxY();
    }

    /*tous les objets dans ce GUI sont xxxxx[0][x][x] et les 2ieme numero du tableau est pour
    le borderlayout donc 0 = nord etc. Chaque ActionListener a une debogue dedans qui te dit c'est quel boutton*/
    private void ContactGUI() {
        D("Création du GUI de contact");
        frame = new JFrame("Ajoute Contact");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(x / 5 * 2 - frame.getWidth(), (y - frame.getHeight()) / 5 * 2);

        //NORTH
        panel[0][1][0] = new JPanel(new FlowLayout());
        label[0][1][0] = new JLabel(contactList.get(0).GetNom());
        label[0][1][0].setFont(new Font("Arial", Font.BOLD, 28));
        panel[0][1][0].add(label[0][1][0]);

        //CENTER
        panel[0][2][0] = new JPanel(new FlowLayout());
        ImageIcon icon = new ImageIcon("" + contactList.get(0).GetPhoto());
        Image image = icon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
        icon = new ImageIcon(image);
        label[0][2][0] = new JLabel(icon);
        panel[0][2][0].add(label[0][2][0]);

        //OUEST
        panel[0][3][0] = new JPanel(new GridLayout(5, 1));
        label[0][3][0] = new JLabel("Nom: " + contactList.get(0).GetNom());
        panel[0][3][0].add(label[0][3][0]);
        label[0][3][1] = new JLabel("# Telephone: " + contactList.get(0).PrintNumero());
        panel[0][3][0].add(label[0][3][1]);
        label[0][3][2] = new JLabel("Location: " + contactList.get(0).GetLocation());
        panel[0][3][0].add(label[0][3][2]);
        label[0][3][3] = new JLabel("Indice: 0");
        panel[0][3][0].add(label[0][3][3]);

        //SOUTH
        panel[0][5][0] = new JPanel(new GridLayout(2, 3));
        for (int i = 1; i < 7; i++) {
            panel[0][5][i] = new JPanel(new FlowLayout());
        }
        boutton[0][5][0] = new JButton("Premier Contact");
        panel[0][5][1].add(boutton[0][5][0]);
        panel[0][5][0].add(panel[0][5][1]);
        boutton[0][5][1] = new JButton("← Contact");
        panel[0][5][2].add(boutton[0][5][1]);
        panel[0][5][0].add(panel[0][5][2]);
        boutton[0][5][2] = new JButton("→ Contact");
        panel[0][5][3].add(boutton[0][5][2]);
        panel[0][5][0].add(panel[0][5][3]);
        boutton[0][5][3] = new JButton("Ajoute Contact");
        panel[0][5][4].add(boutton[0][5][3]);
        panel[0][5][0].add(panel[0][5][4]);
        boutton[0][5][4] = new JButton("Supprime Contact");
        panel[0][5][5].add(boutton[0][5][4]);
        panel[0][5][0].add(panel[0][5][5]);
        boutton[0][5][5] = new JButton("Cherche Contact");
        panel[0][5][6].add(boutton[0][5][5]);
        panel[0][5][0].add(panel[0][5][6]);

        //JFRAME
        panel[0][0][0] = new JPanel(new BorderLayout());
        panel[0][0][0].add(panel[0][5][0], BorderLayout.SOUTH);
        panel[0][0][0].add(panel[0][2][0], BorderLayout.CENTER);
        panel[0][0][0].add(panel[0][3][0], BorderLayout.WEST);
        panel[0][0][0].add(panel[0][1][0], BorderLayout.NORTH);
        frame.add(panel[0][0][0]);
        frame.setVisible(true);

        boutton[0][5][0].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Premier Contact");
                Dispose();
                UpdateGUI(0);
            }
        }
        );

        boutton[0][5][1].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Contact Precedent");
                Dispose();
                for (int i = 0; i < contactList.size(); i++) {
                    if (contactList.get(i).GetNom().equals(label[0][1][0].getText()) && i > 0) {
                        UpdateGUI(i - 1);
                        break;
                    }
                }
            }
        }
        );

        boutton[0][5][2].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Prochain Contact");
                Dispose();
                for (int i = 0; i < contactList.size(); i++) {
                    if (contactList.get(i).GetNom().equals(label[0][1][0].getText()) && i < contactList.size() - 1) {
                        UpdateGUI(i + 1);
                        break;
                    }
                }
            }
        }
        );

        boutton[0][5][3].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Ajoute Contact");
                Dispose();
                AjouteGUI();
            }
        }
        );

        boutton[0][5][4].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Supprime Contact");
                Dispose();
                SupprimeGUI();
            }
        }
        );

        boutton[0][5][5].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Cherche Contact");
                Dispose();
                ChercheGUI();
            }
        }
        );
    }

    /*tous les objets dans ce GUI sont xxxxx[1][x][x] et les 2ieme numero du tableau est pour
    le borderlayout donc 0 = nord etc. Chaque ActionListener a une debogue dedans qui te dit c'est quel boutton*/
    private void AjouteGUI() {
        D("Création du GUI de Ajoute");
        frame2 = new JFrame("Ajoute Contact");
        frame2.setSize(400, 300);
        frame2.setUndecorated(true);
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.setLocation(x / 5 * 2, (y - frame2.getHeight()) / 5 * 2);

        //NORTH
        panel[1][1][0] = new JPanel(new FlowLayout());
        label[1][1][0] = new JLabel("Contact");
        label[1][1][0].setFont(new Font("Arial", Font.BOLD, 28));
        panel[1][1][0].add(label[1][1][0]);

        //CENTER
        panel[1][2][0] = new JPanel(new GridLayout(5, 1));
        for (int x = 0; x < 3; x++) {
            textF[1][2][x] = new JTextField();
            panel[1][2][0].add(textF[1][2][x]);
        }
        panel[1][2][2] = new JPanel(new GridLayout(1, 2));
        panel[1][2][1] = new JPanel(new FlowLayout());
        boutton[1][2][0] = new JButton("Ajoute Photo");
        panel[1][2][1].add(boutton[1][2][0]);
        panel[1][2][2].add(panel[1][2][1]);
        label[1][2][0] = new JLabel("");
        panel[1][2][2].add(label[1][2][0]);
        panel[1][2][0].add(panel[1][2][2]);

        //OUEST
        panel[1][3][0] = new JPanel(new GridLayout(5, 1));
        label[1][3][0] = new JLabel("Nom");
        panel[1][3][0].add(label[1][3][0]);
        label[1][3][1] = new JLabel("# Telephone");
        panel[1][3][0].add(label[1][3][1]);
        label[1][3][2] = new JLabel("Location");
        panel[1][3][0].add(label[1][3][2]);
        label[1][3][3] = new JLabel("Photo");
        panel[1][3][0].add(label[1][3][3]);

        //SOUTH
        panel[1][5][0] = new JPanel(new FlowLayout());
        boutton[1][5][0] = new JButton("Ajoute Contact");
        panel[1][5][0].add(boutton[1][5][0]);

        //JFRAME
        panel[1][0][0] = new JPanel(new BorderLayout());
        panel[1][0][0].add(panel[1][5][0], BorderLayout.SOUTH);
        panel[1][0][0].add(panel[1][2][0], BorderLayout.CENTER);
        panel[1][0][0].add(panel[1][3][0], BorderLayout.WEST);
        panel[1][0][0].add(panel[1][1][0], BorderLayout.NORTH);
        frame2.add(panel[1][0][0]);
        frame2.setVisible(true);

        boutton[1][5][0].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Essai d'ajouter personne");
                Ajoute();
            }
        }
        );
        boutton[1][2][0].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                D("Ajoute Une Photo");
                AjoutePhoto();
            }
        }
        );
        frame2.getRootPane().setDefaultButton(boutton[1][2][0]);
    }

    /*Ceci prends tous les info du text field et ajoute le photo. ajoute l'element du list et fichier, 
    et dispose de tous JFrame extra,*/
    private void Ajoute() {
        Info contact = new Info();
        contact.SetNom(textF[1][2][0].getText());
        contact.SetNumero(textF[1][2][1].getText());
        contact.SetLocation(textF[1][2][2].getText());
        contact.SetPhoto(label[1][2][0].getText());
        if (label[1][2][0].getText().equals("")) {
            contact.SetPhoto("- \t");
        }
        if (contact.GetNom().equals("") || contact.GetNumero().equals("") || contact.GetLocation().equals("")) {
            JOptionPane.showMessageDialog(null, "Il te manque de l'info");
        } else if (contact.GetNumero().length() != 10) {
            JOptionPane.showMessageDialog(null, "Numero Sous form de 0123456789");
        } else {
            try {
                Integer.parseInt(contact.GetNumero());
                contactList.add(contact);
                Alphabet();
                MiseAJour();
                Dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Seulement des numero S.V.P");
            }
        }
    }

    /*ceci laisse le file chooser piger un photo file et ensuite elle l'ajoute au dossier PHOTO*/
    private void AjoutePhoto() {
        try {
            File file = FileChoose();
            label[1][2][0].setText(file.getName());
            file.renameTo(new File("PHOTO" + File.separator + file.getName()));
        } catch (NullPointerException ex) {
            D("Pas de fichier piger");
        }
    }

    /*File Chooser*/
    private File FileChoose() {
        D("Pige une File");
        File file = null;
        JFileChooser fileChooser
                = new JFileChooser(System.getProperty("user.dir"));
        fileChooser.showOpenDialog(null);
        file = fileChooser.getSelectedFile();
        return file;
    }

    /*tous les objets dans ce GUI sont xxxxx[2][x][x] et les 2ieme numero du tableau est pour
    le borderlayout donc 0 = nord etc. Chaque ActionListener a une debogue dedans qui te dit c'est quel boutton*/
    private void SupprimeGUI() {
        D("Création du GUI de supprime");
        frame3 = new JFrame("Supprime Contact");
        frame3.setSize(400, 100);
        frame3.setUndecorated(true);
        frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame3.setLocation(x / 5 * 2, (y - frame3.getHeight()) / 5 * 2);

        //NORTH
        panel[2][1][0] = new JPanel(new FlowLayout());
        label[2][1][0] = new JLabel("Contact");
        label[2][1][0].setFont(new Font("Arial", Font.BOLD, 28));
        panel[2][1][0].add(label[2][1][0]);

        //CENTER
        panel[2][2][0] = new JPanel(new GridLayout(1, 1));
        textF[2][2][0] = new JTextField();
        panel[2][2][0].add(textF[2][2][0]);

        //OUEST
        panel[2][3][0] = new JPanel(new GridLayout(1, 1));
        label[2][3][0] = new JLabel("Nom");
        panel[2][3][0].add(label[2][3][0]);

        //SOUTH
        panel[2][5][0] = new JPanel(new FlowLayout());
        boutton[2][5][0] = new JButton("Supprime Contact");
        panel[2][5][0].add(boutton[2][5][0]);

        //JFRAME
        panel[2][0][0] = new JPanel(new BorderLayout());
        panel[2][0][0].add(panel[2][5][0], BorderLayout.SOUTH);
        panel[2][0][0].add(panel[2][2][0], BorderLayout.CENTER);
        panel[2][0][0].add(panel[2][3][0], BorderLayout.WEST);
        panel[2][0][0].add(panel[2][1][0], BorderLayout.NORTH);
        frame3.add(panel[2][0][0]);
        frame3.setVisible(true);

        boutton[2][5][0].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {

                Supprime();
            }
        }
        );
        frame3.getRootPane().setDefaultButton(boutton[2][5][0]);
    }

    /*Ceci check si le text entrer est null, si il y a quelque chose elle check tous les element du list (toUpperCase 
    enleve le besoin davoir des lettres majiscule) si oui enleve l'element du list et fichier, 
    update le GUI a 0 et dispose de tous JFrame extra*/
    private void Supprime() {
        boolean c = true;
        if (!textF[2][2][0].getText().equals("")) {
            for (int i = 0; i < contactList.size(); i++) {
                if (contactList.get(i).GetNom().toUpperCase().contains(textF[2][2][0].getText().toUpperCase())) {
                    contactList.remove(i);
                    MiseAJour();
                    c = false;
                    UpdateGUI(0);
                }
            }
            if (c == true) {
                JOptionPane.showMessageDialog(null, "Nom, non trouver");
            }
        }
        Dispose();
    }

    /*tous les objets dans ce GUI sont xxxxx[3][x][x] et les 2ieme numero du tableau est pour
    le borderlayout donc 0 = nord etc. Chaque ActionListener a une debogue dedans qui te dit c'est quel boutton*/
    private void ChercheGUI() {
        D("Création du GUI de Cherche");
        frame4 = new JFrame("Cherche Contact");
        frame4.setSize(400, 100);
        frame4.setUndecorated(true);
        frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame4.setLocation(x / 5 * 2, (y - frame4.getHeight()) / 5 * 2);

        //NORTH
        panel[3][1][0] = new JPanel(new FlowLayout());
        label[3][1][0] = new JLabel("Contact");
        label[3][1][0].setFont(new Font("Arial", Font.BOLD, 28));
        panel[3][1][0].add(label[3][1][0]);

        //CENTER
        panel[3][2][0] = new JPanel(new GridLayout(1, 1));
        textF[3][2][0] = new JTextField();
        panel[3][2][0].add(textF[3][2][0]);

        //OUEST
        panel[3][3][0] = new JPanel(new GridLayout(1, 1));
        label[3][3][0] = new JLabel("Nom");
        panel[3][3][0].add(label[3][3][0]);

        //SOUTH
        panel[3][5][0] = new JPanel(new FlowLayout());
        boutton[3][5][0] = new JButton("Cherche Contact");
        panel[3][5][0].add(boutton[3][5][0]);

        //JFRAME
        panel[3][0][0] = new JPanel(new BorderLayout());
        panel[3][0][0].add(panel[3][5][0], BorderLayout.SOUTH);
        panel[3][0][0].add(panel[3][2][0], BorderLayout.CENTER);
        panel[3][0][0].add(panel[3][3][0], BorderLayout.WEST);
        panel[3][0][0].add(panel[3][1][0], BorderLayout.NORTH);
        frame4.add(panel[3][0][0]);
        frame4.setVisible(true);

        boutton[3][5][0].addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent u) {
                Cherche();
            }
        }
        );
        frame4.getRootPane().setDefaultButton(boutton[3][5][0]);
    }

    /*Ceci check si le text entrer est null, si il y a quelque chose elle check tous les element du list (toUpperCase 
    enleve le besoin davoir des lettres majiscule) si oui update le GUI avec l'indice et dispose de tous JFrame extra*/
    private void Cherche() {
        boolean c = true;
        if (!textF[3][2][0].getText().equals("")) {
            for (int i = 0; i < contactList.size(); i++) {
                if (contactList.get(i).GetNom().toUpperCase().contains(textF[3][2][0].getText().toUpperCase())) {
                    UpdateGUI(i);
                    c = false;
                }
            }
            if (c == true) {
                JOptionPane.showMessageDialog(null, "Nom, non trouver");
            }
        }
        Dispose();
    }

    /*tous les objets dans ce GUI sont xxxxx[4][x][x] et les 2ieme numero du tableau est pour
    le borderlayout donc 0 = nord etc. Chaque ActionListener a une debogue dedans qui te dit c'est quel boutton*/
    private void RawGUI() {
        D("Création du GUI d'info");
        frame5 = new JFrame("RAW INFO");
        frame5.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame5.setSize(450, 700);
        frame5.setUndecorated(true);
        frame5.setLocation(x - frame5.getWidth(), 0);

        //NORTH
        panel[4][1][0] = new JPanel(new FlowLayout());
        label[4][1][0] = new JLabel("INFO RAW");
        panel[4][1][0].add(label[4][1][0]);

        //CENTER
        panel[4][2][0] = new JPanel(new GridLayout(1, 1));
        String contacts = "";
        for (int i = 0; i < contactList.size(); i++) {
            contacts = contacts + contactList.get(i).Save() + "\n";
        }
        textA = new JTextArea(contacts);
        textA.setLineWrap(true);
        panel[4][2][0].add(textA);

        //JFRAME
        panel[4][0][0] = new JPanel(new BorderLayout());
        panel[4][0][0].add(panel[4][1][0], BorderLayout.NORTH);
        panel[4][0][0].add(panel[4][2][0], BorderLayout.CENTER);
        frame5.add(panel[4][0][0]);

        textA.setEditable(false);
        frame5.setVisible(true);
    }

    /*Ceci change les textfield et labels en utilisant l'indice du list avec un nombre donner (contactNum)*/
    private void UpdateGUI(int contactNum) {
        D("Update le GUI");
        label[0][1][0].setText(contactList.get(contactNum).GetNom());
        label[0][3][0].setText("Nom: " + contactList.get(contactNum).GetNom());
        label[0][3][1].setText("# Telephone: " + contactList.get(contactNum).PrintNumero());
        label[0][3][2].setText("Location: " + contactList.get(contactNum).GetLocation());
        label[0][3][3].setText("Indice: " + contactNum);
        ImageIcon icon = new ImageIcon("" + contactList.get(contactNum).GetPhoto());
        Image image = icon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
        icon = new ImageIcon(image);
        label[0][2][0].setIcon(icon);
    }

    /*Ceci ferme tous les fenetre extra (ajouteGUI, supprimeGui etc.) Je run ceci avant douvrir nimport quelle 
    JFrame pour qu'il n'ya que 1 JFrame d'extra douvert. (Je run aussi ceci avant que je click next contact)*/
    private void Dispose() {
        D("Ferme tous les windows d'extra");
        if (frame2 != null) {
            frame2.dispose();
        }
        if (frame3 != null) {
            frame3.dispose();
        }
        if (frame4 != null) {
            frame4.dispose();
        }
    }

    /*Ceci mets tous le list de mes contacts en ordre alphabetic (to uppercase chaque bord pour que les lettres
    majiscule ne joue pas de role dans l'arrangement)*/
    private void Alphabet() {
        D("Mets en ordre alphabetic si il y a des personnes");
        if (!contactList.isEmpty()) {
            Collections.sort(contactList, new Comparator<Info>() {
                public int compare(Info nom1, Info nom2) {
                    return (nom1.GetNom().toUpperCase()).compareTo(nom2.GetNom().toUpperCase());
                }
            });
        }
    }

    /*Ceci Update le FICHIER avec les info ajouter*/
    private void MiseAJour() {
        D("Mise a Jour pour le File");
        String contacts = "";
        PrintWriter printWriter = null;
        try {
            printWriter = new PrintWriter(new BufferedWriter(new FileWriter(file, false)));
        } catch (IOException ex) {
        }
        for (int i = 0; i < contactList.size(); i++) {
            printWriter.println(contactList.get(i).Save());
            contacts = contacts + contactList.get(i).Save() + "\n";
        }
        printWriter.close();
        textA.setText(contacts);
    }

    /*commence le Class*/
    public ContactManage() {
        Alphabet();
        MiseAJour();
        Ecran();
        ContactGUI();
        RawGUI();
    }

}
