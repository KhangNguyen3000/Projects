
import java.io.*;
import java.util.*;
import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class Main {

    /*les file et list variable doit etre public car elles vont etre envoyer au class ContactManage (celui qui fait tous le travaille).
    Le seul chose que ce class ici fait est de lire le fichier.*/
    public static File file;
    public static List<Info> contactList = new ArrayList();

    /*ce methode cheque si le file d'info est présent. elle lit le fichier et la sauve, ensuite elle run le Class ContactManage*/
    private Main() {
        try {
            file = new File("INFO.txt");
        } catch (NullPointerException ex) {
            System.out.println("Pas de fichier d'info");
        }
        Start();
        new ContactManage();
    }

    /*Ce methode créer un instance du class Info et ajoute l'info en urilisant le methode Lire*/
    private void Start() {
        try {
            Scanner scan = new Scanner(file);
            while (scan.hasNext()) {
                Info contact = new Info();
                String nom = Lire(scan);
                String numero = Lire(scan);
                String location = Lire(scan);
                String nomPhoto = Lire(scan);
                contact.SetNom(nom);
                contact.SetNumero(numero);
                contact.SetLocation(location);
                contact.SetPhoto(nomPhoto);
                contactList.add(contact);
            }
        } catch (IOException ex) {
            System.out.println("Probleme a lire le fichier");
        }
    }

    
    /* ce methode lit chaque string just que quand elle se rend a "|", elle retourn ensuite se
    string. Ceci laisse le nom ou location avoir plus que un mots ex(premier et dernier nom)*/
    private String Lire(Scanner scan) {
        String string = scan.next();
        boolean continu = true;
        while (scan.hasNext() && continu == true) {
            String temp = scan.next();
            if (temp.equals("|")) {
                continu = false;
            } else {
                string = string + " " + temp;
                System.out.println(string);
            }
        }
        return string;
    }

    /*Commence le pgm*/
    public static void main(String[] args) {
        new Main();
    }
}
