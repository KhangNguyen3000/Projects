
import java.io.*;

/**
 *
 * @author KhangNguyen
 */
public class Info {

    private String nom;
    private String numero;
    private String location;
    private String photoNom;
    private File photo;

    public Info() {
        nom = "John Doe";
        numero = "0000000000";
        location = "Non Connue";
        photoNom = "- \t";
    }

    public void SetNom(String nom) {
        if (!nom.equals("")){
        this.nom = nom;
        }
    }

    public void SetNumero(String numero) {
        if (!numero.equals("")){
        this.numero = numero;
        }
    }

    public void SetLocation(String location) {
        if (!location.equals("")){
        this.location = location;
        }
    }

    public void SetPhoto(String nomPhoto) {
        photoNom = nomPhoto;
        this.photo = new File("PHOTO" + File.separator + nomPhoto);
        if (!photo.exists()) {
            System.out.println("pas de file");
        }
    }

    public String GetNom() {
        return this.nom;
    }

    public String GetNumero() {
        return this.numero;
    }
    
    public String PrintNumero() {
        return "("+numero.charAt(0)+numero.charAt(1)+numero.charAt(2)+") "+numero.charAt(3)+numero.charAt(4)+numero.charAt(5)+"-"+numero.charAt(6)+numero.charAt(7)+numero.charAt(8)+numero.charAt(9);
    }

    public String GetLocation() {
        return this.location;
    }

    public File GetPhoto() {
        return this.photo;
    }
    
    public String Save(){
    return this.nom+"\t| "+this.numero+"\t| "+this.location+"\t| "+this.photoNom+"\t|";
    }
    
}
