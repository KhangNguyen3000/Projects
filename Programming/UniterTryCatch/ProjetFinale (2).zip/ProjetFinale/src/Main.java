
import java.io.*;
import java.util.*;
import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class Main {

    public static File file;
    public static List<Info> contactList = new ArrayList();

    private Main() {
        file = new File("INFO.txt");
        Start();
        new ContactManage();
    }

    private void Start() {
        boolean c = true;
        Scanner scan = null;
        try {
            scan = new Scanner(file);
        } catch (IOException ex) {
            c = false;
        }
        if (c == true) {
            while (scan.hasNext()) {
                Info contact = new Info();
                String nom = Lire(scan);
                String numero = Lire(scan);
                String location = Lire(scan);
                String nomPhoto = Lire(scan);
                contact.SetNom(nom);
                contact.SetNumero(numero);
                contact.SetLocation(location);
                contact.SetPhoto(nomPhoto);
                contactList.add(contact);
            }
        }
    }

    private String Lire(Scanner scan) {
        String string = scan.next();
        boolean c = true;
        while (scan.hasNext() && c == true) {
            String temp = scan.next();
            if (temp.equals("|")) {
                c = false;
            } else {
                string = string +" "+ temp;
                System.out.println(string);
            }
        }
        return string;
    }

    public static void main(String[] args) {
        new Main();
    }
}
