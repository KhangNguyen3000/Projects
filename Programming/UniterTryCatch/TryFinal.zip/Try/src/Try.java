
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CECCE
 */
public class Try {
     
       public static void main(String args[]) {
           int i = 0;
        
        do {
            String strI = JOptionPane.showInputDialog(null, "Nombre dessus 2");
            if (strI == null) {
                System.exit(0);
            }
            try{
            i = Integer.parseInt(strI);
            System.out.println(i);
            }catch (NumberFormatException e){
            JOptionPane.showMessageDialog(null, strI+" n'est pas un nombre.");
            }
        } while (i < 2);
        
    }
}
