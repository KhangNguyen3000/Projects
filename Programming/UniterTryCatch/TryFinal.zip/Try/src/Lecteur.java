
import java.util.Scanner;
import java.io.*;

/**
 *
 * @author CECCE
 */
public class Lecteur {

    public static void main(String args[]) throws IOException {
        int i = 0;
        int b = 0;
        try {
            File a = new File("DATA" + File.separator + "monData2.txt");
            Scanner scan = new Scanner(a);
            while (scan.hasNext()) {
                int temp = scan.nextInt();
                i++;
                b = b + temp;
                System.out.print(temp+ " ");
            }
        } catch (FileNotFoundException ex) {
            System.out.println("File Exist pas");
        }
        b = b / i;
        System.out.println("");
        System.out.println("Moyenne = " + b);
    }
}
