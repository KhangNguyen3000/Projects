
import java.util.Scanner;
import java.io.*;
import javax.swing.*;

/**
 *
 * @author CECCE
 */
public class Lectfinal {

    public double tax = .13;

    public Lectfinal() {
        Scanner a = Scanneur();
        PrintWriter p = Printeur();
        Travail(a, p);
    }

    public Scanner Scanneur() {
        File fichier = FileChoose();
        try {
            Scanner scan = new Scanner(fichier);
            return scan;
        } catch (IOException ex) {
        }
        return null;
    }

    public PrintWriter Printeur() {
        File fichier = FileChoose();
        try {
            PrintWriter p = new PrintWriter(new BufferedWriter(new FileWriter(fichier, false)));
            return p;
        } catch (IOException ex) {
        }
        return null;
    }

    public File FileChoose() {
        int i = 0;
        int b = 0;
        boolean c = true;
        do {
            File fichier = null;
            JFileChooser fileChooser
                    = new JFileChooser(System.getProperty("user.dir"));
            int valRetour = fileChooser.showOpenDialog(null);
            if (valRetour == 0) {
                fichier = fileChooser.getSelectedFile();
                c = false;
                if (!fichier.isFile()) {
                    c = true;
                }

            } else {
                System.exit(0);
            }
            return fichier;
        } while (c == true);
    }

    public void Travail(Scanner scan, PrintWriter p) {
        int i = 0;
        int b = 0;
        while (scan.hasNext()) {
            if (scan.hasNextInt()) {
                i++;
                int temp = scan.nextInt();
                b = b + temp;
            } else {
                String nom = scan.next();
                System.out.println("Nom = " + nom + "  |  Nombre d'objets = " + i + "  |  Prix = " + b + "$  |  Total = " + ((b) + b * tax) + "$");
                p.println("Nom = " + nom + "  |  Nombre d'objets = " + i + "  |  Prix = " + b + "$  |  Total = " + ((b) + b * tax) + "$");
                i = 0;
                b = 0;
            }
        }
        p.close();
    }

    public static void main(String args[]) {
        new Lectfinal();
    }
}
