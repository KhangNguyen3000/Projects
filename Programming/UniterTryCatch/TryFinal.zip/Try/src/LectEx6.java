
import javax.swing.JOptionPane;
import java.util.Scanner;
import java.io.*;
import javax.swing.JFileChooser;

public class LectEx6 {

    public static void Mathemagie(int num) {
        int carrer = num * num;
        System.out.println("Le carrée de " + num + " est " + carrer);
        int plus = num + num;
        System.out.println("Le nombre x 2 de " + num + " est " + plus);
    }

    public static void main(String[] args) throws IOException {
        int num;
        try {
            File fichier = null;
            JFileChooser fileChooser
                    = new JFileChooser(System.getProperty("user.dir"));
            int valRetour = fileChooser.showOpenDialog(null);
            if (valRetour == 0) {
                fichier = fileChooser.getSelectedFile();
                if (!fichier.isFile()) {
                    throw new FileNotFoundException("Pas un fichier");
                }
            } else {
                throw new FileNotFoundException("Problème avec FC");
            }
            Scanner scan = new Scanner(fichier);
            while (scan.hasNextInt()) {
                num = scan.nextInt();
                Mathemagie(num);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Oops - le nom de fichier est mauvais.");
        }
    }
}
