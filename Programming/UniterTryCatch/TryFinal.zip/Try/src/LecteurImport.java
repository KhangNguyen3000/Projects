
import java.util.Scanner;
import java.io.*;

/**
 *
 * @author CECCE
 */
public class LecteurImport {

    public static void main(String args[]) throws IOException {
        int min = 2147483647;
        int max = -2147483647;
        int b = 0;
        try {
            File a = new File("DATA" + File.separator + "dataEx5.txt");
            Scanner scan = new Scanner(a);
            while (scan.hasNext()) {
                if(scan.hasNextInt()) {
                    int temp = scan.nextInt();
                    min = Math.min(temp, min);
                    max = Math.max(temp, max);
                    b = b + temp;
                    System.out.print(temp + " ");
                }else{
                scan.next();
                }
            }
        } catch (FileNotFoundException ex) {
            System.out.println("File Exist pas");
        }
        System.out.println("");
        System.out.println("Somme = " + b);
        System.out.println("Max = " + max);
        System.out.println("Min = " + min);
    }
}
