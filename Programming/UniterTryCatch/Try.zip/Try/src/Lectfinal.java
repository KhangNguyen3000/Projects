
import java.util.Scanner;
import java.io.*;

/**
 *
 * @author CECCE
 */
public class Lectfinal{

    public double tax = .13;

    public Lectfinal() throws IOException {
        int i = 0;
        int b = 0;
        try {
            File a = new File("DATA" + File.separator + "dataDernierEx.txt");
            PrintWriter p = new PrintWriter(new BufferedWriter(new FileWriter("DATA" + File.separator + "dataDernierEx2.txt", false)));
            Scanner scan = new Scanner(a);
            while (scan.hasNext()) {
                if (scan.hasNextInt()) {
                    i++;
                    int temp = scan.nextInt();
                    b = b + temp;
                } else {
                    String nom = scan.next();
                    System.out.println("Nom = " + nom + "  |  Nombre d'objets = " + i + "  |  Prix = " + b + "$  |  Total = " + ((b) + b * tax) + "$");
                    p.println("Nom = " + nom + "  |  Nombre d'objets = " + i + "  |  Prix = " + b + "$  |  Total = " + ((b) + b * tax) + "$");
                    i = 0;
                    b = 0;
                }
            }
            p.close();
        } catch (FileNotFoundException ex) {
            System.out.println("File Exist pas");
        }
    }

    public static void main(String args[]) throws IOException{
        new Lectfinal();
    }
}
