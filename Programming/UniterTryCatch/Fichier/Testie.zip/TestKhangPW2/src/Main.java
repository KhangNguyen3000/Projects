
import java.io.*;
import java.util.Scanner;
import javax.swing.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author KhangNguyen
 */
public class Main {

    public static int i = 0;
    public static String[] args = {};
    public static File fichierS = null;
    public static File fichierP = null;

    public static File FileChoose() {
        boolean continu = true;
        do {
            File fichier = null;
            JFileChooser fileChooser
                    = new JFileChooser(System.getProperty("user.dir"));
            int valRetour = fileChooser.showOpenDialog(null);
            if (valRetour == 0) {
                fichier = fileChooser.getSelectedFile();
                continu = false;
                if (!fichier.isFile()) {
                    continu = true;
                }

            } else {
                System.exit(0);
            }
            return fichier;
        } while (continu == true);
    }

    public static void main(String args[]) {
        fichierS = FileChoose();
        fichierP = FileChoose();
        try {
            Scanner scan = new Scanner(fichierS);
            while (scan.hasNext()) {
                scan.next();
                i++;
            }
        } catch (IOException ex) {
        }
        TestKhang.main(args);
    }

}
